package com.example.bleapplication;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.bleapplication.util.PermissionHelper;
import android.bluetooth.*;
import android.bluetooth.le.*;

import java.nio.charset.StandardCharsets;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.UUID;

@SuppressLint("SetTextI18n")
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "HeartRateBLE";
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothGatt bluetoothGatt;
    private BluetoothDevice targetDevice;

    // UI Components
    private TextView accelerometerX, accelerometerY, accelerometerZ;
    private TextView gyroscopeX, gyroscopeY, gyroscopeZ;
    private TextView temperatureValue;
    private Button toggleNotify;
    private boolean isNotifyEnabled = false;
    private Queue<BluetoothGattCharacteristic> readQueue = new LinkedList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 初始化视图
        accelerometerX = findViewById(R.id.accelerometer_x);
        accelerometerY = findViewById(R.id.accelerometer_y);
        accelerometerZ = findViewById(R.id.accelerometer_z);

        gyroscopeX = findViewById(R.id.gyroscope_x);
        gyroscopeY = findViewById(R.id.gyroscope_y);
        gyroscopeZ = findViewById(R.id.gyroscope_z);

        temperatureValue = findViewById(R.id.temperature_value);

        toggleNotify = findViewById(R.id.toggleNotify);
        toggleNotify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleNotify();
            }
        });

        // 初始化蓝牙适配器
        final BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = bluetoothManager.getAdapter();

        if (PermissionHelper.checkAndRequestPermissions(this)) {
            // 所有权限都已授予
            startBluetoothProcess();
        } else {
            Toast.makeText(this,"权限申请不正确,应用不会继续执行.",Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,@NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (PermissionHelper.handlePermissionResult(requestCode, permissions, grantResults)) {
            // 所有权限都已授予
            startBluetoothProcess();
        } else {
            // 有权限被拒绝
            String description = PermissionHelper.getDeniedPermissionDescription(this);
            Toast.makeText(this,description,Toast.LENGTH_LONG).show();
        }
    }

    private void startBluetoothProcess() {
        if (!checkBluetooth()) return;
        startScan();
    }

    private boolean checkBluetooth() {
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            Toast.makeText(this, "请先启用蓝牙", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void startScan() {
        bluetoothAdapter.startLeScan(leScanCallback);
    }

    private final BluetoothAdapter.LeScanCallback leScanCallback = new BluetoothAdapter.LeScanCallback() {
        @Override
        public void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord) {
            if (device.getName() != null && device.getName().contains("Simple")) {
                Toast.makeText(MainActivity.this,String.format("找到设备:%s",device.getAddress().toString()),Toast.LENGTH_LONG).show();
                targetDevice = device;
                bluetoothAdapter.stopLeScan(leScanCallback);
                connectToDevice();
            }
        }
    };

    private void connectToDevice() {
        if (targetDevice == null) return;
        bluetoothGatt = targetDevice.connectGatt(this, false, gattCallback);
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                gatt.discoverServices();
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                processServices(gatt.getServices());
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                // updateCharacteristicUI(characteristic);
            }
            // 无论成功与否都继续读取下一个
            readNextCharacteristic();
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            receiveNotifyData(characteristic);
        }
    };

    private void processServices(List<BluetoothGattService> services) {
        for (BluetoothGattService service : services) {
            String serviceUuid = service.getUuid().toString().toUpperCase();

            if (serviceUuid.equals("0000180A-0000-1000-8000-00805F9B34FB")) {
                readDeviceInfoCharacteristics(service);
            } else if (serviceUuid.equals("0000FFE0-0000-1000-8000-00805F9B34FB")) {
                setupCommunicationCharacteristics(service);
            }
        }
    }

    private void readDeviceInfoCharacteristics(BluetoothGattService service) {
        // 清空旧队列
        readQueue.clear();

        // 填充可读特征到队列
        for (BluetoothGattCharacteristic characteristic : service.getCharacteristics()) {
            if ((characteristic.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) != 0) {
                readQueue.add(characteristic);
            }
        }

        // 开始顺序读取
        readNextCharacteristic();
    }

    private void readNextCharacteristic() {
        if (!readQueue.isEmpty()) {
            BluetoothGattCharacteristic next = readQueue.poll();
            if (!bluetoothGatt.readCharacteristic(next)) {
                // 读取失败时继续下一个
                readNextCharacteristic();
            }
        }
    }

    private String getCharacteristicName(String uuid) {
        switch (uuid.substring(4, 8)) {
            case "2A23": return "设备ID";
            case "2A24": return "型号ID";
            case "2A25": return "序列号";
            case "2A26": return "固件版本";
            case "2A27": return "硬件版本";
            case "2A28": return "软件版本";
            case "2A29": return "制造商名称";
            default: return "未知特征";
        }
    }

    private BluetoothGattCharacteristic writeCharacteristic;
    private BluetoothGattCharacteristic notifyCharacteristic;

    private void setupCommunicationCharacteristics(BluetoothGattService service) {
        for (BluetoothGattCharacteristic characteristic : service.getCharacteristics()) {
            String uuid = characteristic.getUuid().toString().toUpperCase();

            if (uuid.equals("0000FFE2-0000-1000-8000-00805F9B34FB")) {
                writeCharacteristic = characteristic;
            } else if (uuid.equals("0000FFE1-0000-1000-8000-00805F9B34FB")) {
                notifyCharacteristic = characteristic;
            }
        }
    }

    private void toggleNotify() {
        if (notifyCharacteristic == null) return;

        isNotifyEnabled = !isNotifyEnabled;
        setNotificationEnabled(notifyCharacteristic, isNotifyEnabled);
        toggleNotify.setText(isNotifyEnabled ? "暂停采集" : "采集数据");
    }

    private void setNotificationEnabled(BluetoothGattCharacteristic characteristic, boolean enable) {
        bluetoothGatt.setCharacteristicNotification(characteristic, enable);

        BluetoothGattDescriptor descriptor = characteristic.getDescriptor(
                UUID.fromString("00002902-0000-1000-8000-00805F9B34FB"));
        if (descriptor != null) {
            descriptor.setValue(enable ?
                    BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE :
                    BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE);
            bluetoothGatt.writeDescriptor(descriptor);
        }
    }


    // 处理蓝牙通知数据
    private void receiveNotifyData(BluetoothGattCharacteristic characteristic) {
        byte[] rawData = characteristic.getValue();

        // 确保数据长度足够 (至少14字节)
        if (rawData == null || rawData.length < 14) {
            return;
        }

        // 解析原始数据
        short rawAccelX = (short)((rawData[0] << 8) | (rawData[1] & 0xFF));
        short rawAccelY = (short)((rawData[2] << 8) | (rawData[3] & 0xFF));
        short rawAccelZ = (short)((rawData[4] << 8) | (rawData[5] & 0xFF));
        short rawTemp = (short)((rawData[6] << 8) | (rawData[7] & 0xFF));
        short rawGyroX = (short)((rawData[8] << 8) | (rawData[9] & 0xFF));
        short rawGyroY = (short)((rawData[10] << 8) | (rawData[11] & 0xFF));
        short rawGyroZ = (short)((rawData[12] << 8) | (rawData[13] & 0xFF));

        // 转换为实际值
        float accelX = rawAccelX * (2.0f / 32768.0f); // 单位: g
        float accelY = rawAccelY * (2.0f / 32768.0f);
        float accelZ = rawAccelZ * (2.0f / 32768.0f);

        float temperature = (rawTemp / 340.0f) + 36.53f; // 单位: °C

        float gyroX = rawGyroX * (1000.0f / 32768.0f); // 单位: °/s
        float gyroY = rawGyroY * (1000.0f / 32768.0f);
        float gyroZ = rawGyroZ * (1000.0f / 32768.0f);

        // 更新UI
        runOnUiThread(() -> {
            // 加速度计数据 (转换为m/s²: 1g = 9.80665 m/s²)
            accelerometerX.setText(String.format("%.2f", accelX * 9.80665f));
            accelerometerY.setText(String.format("%.2f", accelY * 9.80665f));
            accelerometerZ.setText(String.format("%.2f", accelZ * 9.80665f));

            // 陀螺仪数据
            gyroscopeX.setText(String.format("%.2f", gyroX));
            gyroscopeY.setText(String.format("%.2f", gyroY));
            gyroscopeZ.setText(String.format("%.2f", gyroZ));

            // 温度数据
            temperatureValue.setText(String.format("%.1f°C", temperature));
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (bluetoothGatt != null) {
            bluetoothGatt.disconnect();
            bluetoothGatt.close();
        }
    }


    // 新增字节数组转十六进制工具方法
    private static String bytesToHex(byte[] bytes) {
        if (bytes == null) return "null";
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X ", b));
        }
        return sb.toString().trim(); // 示例输出："A0 B4 FF"
    }
}