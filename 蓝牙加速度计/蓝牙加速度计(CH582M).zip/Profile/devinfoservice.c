#include "CONFIG.h"
#include "devinfoservice.h"

/*********************************************************************
 * UUID 定义（16-bit Bluetooth SIG 分配）
 *********************************************************************/

// Device Information Service UUID
const uint8_t devInfoServUUID[ATT_BT_UUID_SIZE] = { LO_UINT16(DEVINFO_SERV_UUID), HI_UINT16(DEVINFO_SERV_UUID) };
// 各个 Characteristic UUID
const uint8_t devInfoSystemIdUUID[]     = { LO_UINT16(SYSTEM_ID_UUID), HI_UINT16(SYSTEM_ID_UUID) };
const uint8_t devInfoModelNumberUUID[]  = { LO_UINT16(MODEL_NUMBER_UUID), HI_UINT16(MODEL_NUMBER_UUID) };
const uint8_t devInfoSerialNumberUUID[] = { LO_UINT16(SERIAL_NUMBER_UUID), HI_UINT16(SERIAL_NUMBER_UUID) };
const uint8_t devInfoFirmwareRevUUID[]  = { LO_UINT16(FIRMWARE_REV_UUID), HI_UINT16(FIRMWARE_REV_UUID) };
const uint8_t devInfoHardwareRevUUID[]  = { LO_UINT16(HARDWARE_REV_UUID), HI_UINT16(HARDWARE_REV_UUID) };
const uint8_t devInfoSoftwareRevUUID[]  = { LO_UINT16(SOFTWARE_REV_UUID), HI_UINT16(SOFTWARE_REV_UUID) };
const uint8_t devInfoMfrNameUUID[]      = { LO_UINT16(MANUFACTURER_NAME_UUID), HI_UINT16(MANUFACTURER_NAME_UUID) };
const uint8_t devInfo11073CertUUID[]    = { LO_UINT16(IEEE_11073_CERT_DATA_UUID), HI_UINT16(IEEE_11073_CERT_DATA_UUID) };
const uint8_t devInfoPnpIdUUID[]        = { LO_UINT16(PNP_ID_UUID), HI_UINT16(PNP_ID_UUID) };
/*********************************************************************
 * 特性值定义
 *********************************************************************/

// GATT 服务类型（用于主服务描述符）
static const gattAttrType_t devInfoService = { ATT_BT_UUID_SIZE, devInfoServUUID };

// 各特性值及属性（均为只读 GATT_PROP_READ）
static uint8_t devInfoSystemIdProps = GATT_PROP_READ;
static uint8_t devInfoSystemId[DEVINFO_SYSTEM_ID_LEN] = {0};  // 可通过 Set 接口设置

static uint8_t devInfoModelNumberProps = GATT_PROP_READ;
static const uint8_t devInfoModelNumber[] = "Model Number";

static uint8_t devInfoSerialNumberProps = GATT_PROP_READ;
static const uint8_t devInfoSerialNumber[] = "Serial Number";

static uint8_t devInfoFirmwareRevProps = GATT_PROP_READ;
static const uint8_t devInfoFirmwareRev[] = "Firmware Revision";

static uint8_t devInfoHardwareRevProps = GATT_PROP_READ;
static const uint8_t devInfoHardwareRev[] = "Hardware Revision";

static uint8_t devInfoSoftwareRevProps = GATT_PROP_READ;
static const uint8_t devInfoSoftwareRev[] = "Software Revision";

static uint8_t devInfoMfrNameProps = GATT_PROP_READ;
static const uint8_t devInfoMfrName[] = "Manufacturer Name";

// 11073 认证数据，固定值（实验用途）
static uint8_t devInfo11073CertProps = GATT_PROP_READ;
static const uint8_t devInfo11073Cert[] = {
    DEVINFO_11073_BODY_EXP, 0x00, 'e','x','p','e','r','i','m','e','n','t','a','l'
};

// PnP ID 信息，静态设置
static uint8_t devInfoPnpIdProps = GATT_PROP_READ;
static uint8_t devInfoPnpId[DEVINFO_PNP_ID_LEN] = {
    1,                          // Vendor ID Source: Bluetooth SIG
    LO_UINT16(0x07D7), HI_UINT16(0x07D7), // Vendor ID: WCH
    LO_UINT16(0x0000), HI_UINT16(0x0000), // Product ID
    LO_UINT16(0x0110), HI_UINT16(0x0110)  // Product Version
};

//设备信息服务的 GATT 属性表
static gattAttribute_t devInfoAttrTbl[] = {
    // 设备信息服务（Primary Service）
    {
        {ATT_BT_UUID_SIZE, primaryServiceUUID},
        GATT_PERMIT_READ,
        0,
        (uint8_t *)&devInfoService
    },

    // System ID 特征声明
    {
        {ATT_BT_UUID_SIZE, characterUUID},
        GATT_PERMIT_READ,
        0,
        &devInfoSystemIdProps
    },
    // System ID 特征值
    {
        {ATT_BT_UUID_SIZE, devInfoSystemIdUUID},
        GATT_PERMIT_READ,
        0,
        (uint8_t *)devInfoSystemId
    },

    // Model Number（型号）特征声明
    {
        {ATT_BT_UUID_SIZE, characterUUID},
        GATT_PERMIT_READ,
        0,
        &devInfoModelNumberProps
    },
    // Model Number 特征值
    {
        {ATT_BT_UUID_SIZE, devInfoModelNumberUUID},
        GATT_PERMIT_READ,
        0,
        (uint8_t *)devInfoModelNumber
    },

    // Serial Number（序列号）特征声明
    {
        {ATT_BT_UUID_SIZE, characterUUID},
        GATT_PERMIT_READ,
        0,
        &devInfoSerialNumberProps
    },
    // Serial Number 特征值
    {
        {ATT_BT_UUID_SIZE, devInfoSerialNumberUUID},
        GATT_PERMIT_READ,
        0,
        (uint8_t *)devInfoSerialNumber
    },

    // Firmware Revision（固件版本）特征声明
    {
        {ATT_BT_UUID_SIZE, characterUUID},
        GATT_PERMIT_READ,
        0,
        &devInfoFirmwareRevProps
    },
    // Firmware Revision 特征值
    {
        {ATT_BT_UUID_SIZE, devInfoFirmwareRevUUID},
        GATT_PERMIT_READ,
        0,
        (uint8_t *)devInfoFirmwareRev
    },

    // Hardware Revision（硬件版本）特征声明
    {
        {ATT_BT_UUID_SIZE, characterUUID},
        GATT_PERMIT_READ,
        0,
        &devInfoHardwareRevProps
    },
    // Hardware Revision 特征值
    {
        {ATT_BT_UUID_SIZE, devInfoHardwareRevUUID},
        GATT_PERMIT_READ,
        0,
        (uint8_t *)devInfoHardwareRev
    },

    // Software Revision（软件版本）特征声明
    {
        {ATT_BT_UUID_SIZE, characterUUID},
        GATT_PERMIT_READ,
        0,
        &devInfoSoftwareRevProps
    },
    // Software Revision 特征值
    {
        {ATT_BT_UUID_SIZE, devInfoSoftwareRevUUID},
        GATT_PERMIT_READ,
        0,
        (uint8_t *)devInfoSoftwareRev
    },

    // Manufacturer Name（制造商名称）特征声明
    {
        {ATT_BT_UUID_SIZE, characterUUID},
        GATT_PERMIT_READ,
        0,
        &devInfoMfrNameProps
    },
    // Manufacturer Name 特征值
    {
        {ATT_BT_UUID_SIZE, devInfoMfrNameUUID},
        GATT_PERMIT_READ,
        0,
        (uint8_t *)devInfoMfrName
    },

    // IEEE 11073 认证数据特征声明
    {
        {ATT_BT_UUID_SIZE, characterUUID},
        GATT_PERMIT_READ,
        0,
        &devInfo11073CertProps
    },
    // IEEE 11073 认证数据特征值
    {
        {ATT_BT_UUID_SIZE, devInfo11073CertUUID},
        GATT_PERMIT_READ,
        0,
        (uint8_t *)devInfo11073Cert
    },

    // PnP ID 特征声明
    {
        {ATT_BT_UUID_SIZE, characterUUID},
        GATT_PERMIT_READ,
        0,
        &devInfoPnpIdProps
    },
    // PnP ID 特征值
    {
        {ATT_BT_UUID_SIZE, devInfoPnpIdUUID},
        GATT_PERMIT_READ,
        0,
        (uint8_t *)devInfoPnpId
    }
};

// 设备信息服务的读操作回调函数
static bStatus_t devInfo_ReadAttrCB(uint16_t connHandle, gattAttribute_t *pAttr,
                                    uint8_t *pValue, uint16_t *pLen, uint16_t offset,
                                    uint16_t maxLen, uint8_t method);

// GATT 回调函数结构体，仅实现读操作
gattServiceCBs_t devInfoCBs = {
    devInfo_ReadAttrCB, // 读属性的回调函数
    NULL,               // 不支持写操作
    NULL                // 不需要鉴权
};

/*********************************************************************
 * @fn      DevInfo_AddService
 *
 * @brief   初始化 Device Information 服务，将属性表注册到 GATT Server。
 *
 * @return  操作结果：成功或失败
 */
bStatus_t DevInfo_AddService(void)
{
    // 向 GATT Server 注册设备信息服务的属性表和回调函数
    return GATTServApp_RegisterService(devInfoAttrTbl,
                                       GATT_NUM_ATTRS(devInfoAttrTbl),
                                       GATT_MAX_ENCRYPT_KEY_SIZE,
                                       &devInfoCBs);
}

/*********************************************************************
 * @fn      DevInfo_SetParameter
 *
 * @brief   设置设备信息参数。
 *
 * @param   param - 参数 ID（如 DEVINFO_SYSTEM_ID）
 * @param   len   - 数据长度
 * @param   value - 数据指针（类型依 param 而定）
 *
 * @return  bStatus_t
 */
bStatus_t DevInfo_SetParameter(uint8_t param, uint16_t len, void *value)
{
    bStatus_t ret = SUCCESS;

    switch(param)
    {
        case DEVINFO_SYSTEM_ID:
            // 复制系统 ID 数据
            tmos_memcpy(devInfoSystemId, value, len);
            break;

        default:
            // 不支持的参数
            ret = INVALIDPARAMETER;
            break;
    }

    return ret;
}

/*********************************************************************
 * @fn      DevInfo_GetParameter
 *
 * @brief   获取设备信息参数。
 *
 * @param   param - 参数 ID
 * @param   value - 返回的数据缓冲区指针（调用者提供）
 *
 * @return  bStatus_t
 */
bStatus_t DevInfo_GetParameter(uint8_t param, void *value)
{
    bStatus_t ret = SUCCESS;

    switch(param)
    {
        case DEVINFO_SYSTEM_ID:
            tmos_memcpy(value, devInfoSystemId, sizeof(devInfoSystemId));
            break;
        case DEVINFO_MODEL_NUMBER:
            tmos_memcpy(value, devInfoModelNumber, sizeof(devInfoModelNumber));
            break;
        case DEVINFO_SERIAL_NUMBER:
            tmos_memcpy(value, devInfoSerialNumber, sizeof(devInfoSerialNumber));
            break;
        case DEVINFO_FIRMWARE_REV:
            tmos_memcpy(value, devInfoFirmwareRev, sizeof(devInfoFirmwareRev));
            break;
        case DEVINFO_HARDWARE_REV:
            tmos_memcpy(value, devInfoHardwareRev, sizeof(devInfoHardwareRev));
            break;
        case DEVINFO_SOFTWARE_REV:
            tmos_memcpy(value, devInfoSoftwareRev, sizeof(devInfoSoftwareRev));
            break;
        case DEVINFO_MANUFACTURER_NAME:
            tmos_memcpy(value, devInfoMfrName, sizeof(devInfoMfrName));
            break;
        case DEVINFO_11073_CERT_DATA:
            tmos_memcpy(value, devInfo11073Cert, sizeof(devInfo11073Cert));
            break;
        case DEVINFO_PNP_ID:
            tmos_memcpy(value, devInfoPnpId, sizeof(devInfoPnpId));
            break;
        default:
            ret = INVALIDPARAMETER;
            break;
    }

    return ret;
}

/*********************************************************************
 * @fn      devInfo_ReadAttrCB
 *
 * @brief   处理 GATT 读属性回调，用于响应中心设备的读取请求。
 *
 * @param   connHandle - 当前连接句柄
 * @param   pAttr      - 被读取的属性指针
 * @param   pValue     - 读取数据输出缓存
 * @param   pLen       - 实际读取长度输出
 * @param   offset     - 读取偏移
 * @param   maxLen     - 允许读取的最大长度
 * @param   method     - GATT 方法（未使用）
 *
 * @return  bStatus_t  - 读取是否成功
 */
static bStatus_t devInfo_ReadAttrCB(uint16_t connHandle, gattAttribute_t *pAttr,
                                    uint8_t *pValue, uint16_t *pLen, uint16_t offset,
                                    uint16_t maxLen, uint8_t method)
{
    bStatus_t status = SUCCESS;
    uint16_t uuid = BUILD_UINT16(pAttr->type.uuid[0], pAttr->type.uuid[1]);

    switch(uuid)
    {
        case SYSTEM_ID_UUID:
            // 验证偏移
            if(offset >= sizeof(devInfoSystemId))
                status = ATT_ERR_INVALID_OFFSET;
            else
            {
                *pLen = MIN(maxLen, sizeof(devInfoSystemId) - offset);
                tmos_memcpy(pValue, &devInfoSystemId[offset], *pLen);
            }
            break;

        case MODEL_NUMBER_UUID:
            if(offset >= (sizeof(devInfoModelNumber) - 1))
                status = ATT_ERR_INVALID_OFFSET;
            else
            {
                *pLen = MIN(maxLen, (sizeof(devInfoModelNumber) - 1) - offset);
                tmos_memcpy(pValue, &devInfoModelNumber[offset], *pLen);
            }
            break;

        case SERIAL_NUMBER_UUID:
            if(offset >= (sizeof(devInfoSerialNumber) - 1))
                status = ATT_ERR_INVALID_OFFSET;
            else
            {
                *pLen = MIN(maxLen, (sizeof(devInfoSerialNumber) - 1) - offset);
                tmos_memcpy(pValue, &devInfoSerialNumber[offset], *pLen);
            }
            break;

        case FIRMWARE_REV_UUID:
            if(offset >= (sizeof(devInfoFirmwareRev) - 1))
                status = ATT_ERR_INVALID_OFFSET;
            else
            {
                *pLen = MIN(maxLen, (sizeof(devInfoFirmwareRev) - 1) - offset);
                tmos_memcpy(pValue, &devInfoFirmwareRev[offset], *pLen);
            }
            break;

        case HARDWARE_REV_UUID:
            if(offset >= (sizeof(devInfoHardwareRev) - 1))
                status = ATT_ERR_INVALID_OFFSET;
            else
            {
                *pLen = MIN(maxLen, (sizeof(devInfoHardwareRev) - 1) - offset);
                tmos_memcpy(pValue, &devInfoHardwareRev[offset], *pLen);
            }
            break;

        case SOFTWARE_REV_UUID:
            if(offset >= (sizeof(devInfoSoftwareRev) - 1))
                status = ATT_ERR_INVALID_OFFSET;
            else
            {
                *pLen = MIN(maxLen, (sizeof(devInfoSoftwareRev) - 1) - offset);
                tmos_memcpy(pValue, &devInfoSoftwareRev[offset], *pLen);
            }
            break;

        case MANUFACTURER_NAME_UUID:
            if(offset >= (sizeof(devInfoMfrName) - 1))
                status = ATT_ERR_INVALID_OFFSET;
            else
            {
                *pLen = MIN(maxLen, (sizeof(devInfoMfrName) - 1) - offset);
                tmos_memcpy(pValue, &devInfoMfrName[offset], *pLen);
            }
            break;

        case IEEE_11073_CERT_DATA_UUID:
            if(offset >= sizeof(devInfo11073Cert))
                status = ATT_ERR_INVALID_OFFSET;
            else
            {
                *pLen = MIN(maxLen, sizeof(devInfo11073Cert) - offset);
                tmos_memcpy(pValue, &devInfo11073Cert[offset], *pLen);
            }
            break;

        case PNP_ID_UUID:
            if(offset >= sizeof(devInfoPnpId))
                status = ATT_ERR_INVALID_OFFSET;
            else
            {
                *pLen = MIN(maxLen, sizeof(devInfoPnpId) - offset);
                tmos_memcpy(pValue, &devInfoPnpId[offset], *pLen);
            }
            break;

        default:
            // 未找到对应 UUID
            *pLen = 0;
            status = ATT_ERR_ATTR_NOT_FOUND;
            break;
    }

    return status;
}
