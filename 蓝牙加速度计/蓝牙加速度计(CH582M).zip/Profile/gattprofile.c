#include "CONFIG.h"
#include "gattprofile.h"

// Virtual Serial Profile 服务
#define VIRTUALSERIAL_TX_VALUE_POS    4  // TX 特征在属性数组中的位置

// Virtual Serial 服务 UUID
const uint8_t virtualSerialServUUID[ATT_BT_UUID_SIZE] = {
    LO_UINT16(VIRTUALSERIAL_SERV_UUID), HI_UINT16(VIRTUALSERIAL_SERV_UUID)};

// 各个特征的 UUID 定义
const uint8_t virtualSerialRxUUID[ATT_BT_UUID_SIZE] = {
    LO_UINT16(VIRTUALSERIAL_RX_UUID), HI_UINT16(VIRTUALSERIAL_RX_UUID)};
const uint8_t virtualSerialTxUUID[ATT_BT_UUID_SIZE] = {
    LO_UINT16(VIRTUALSERIAL_TX_UUID), HI_UINT16(VIRTUALSERIAL_TX_UUID)};

// 存储 Virtual Serial 回调函数
static virtualSerialCBs_t *virtualSerial_AppCBs = NULL;

// Virtual Serial 服务的属性定义
static const gattAttrType_t virtualSerialService = {ATT_BT_UUID_SIZE, virtualSerialServUUID};
// 各个特征的属性
static uint8_t virtualSerialRxProps = GATT_PROP_WRITE;  // RX 特征可写
static uint8_t virtualSerialTxProps = GATT_PROP_NOTIFY; // TX 特征可通知

// 各个特征的值
static uint8_t virtualSerialRx[VIRTUALSERIAL_RX_LEN] = {0}; // 接收缓冲区
static uint8_t virtualSerialTx[VIRTUALSERIAL_TX_LEN] = {0}; // 发送缓冲区

// Virtual Serial TX 特征配置
static gattCharCfg_t virtualSerialTxConfig[PERIPHERAL_MAX_CONNECTION];

// 属性表定义
static gattAttribute_t virtualSerialAttrTbl[] = {
    // Virtual Serial 服务
    {
        {ATT_BT_UUID_SIZE, primaryServiceUUID},
        GATT_PERMIT_READ,
        0,
        (uint8_t *)&virtualSerialService
    },
    // RX 特征声明
    {
        {ATT_BT_UUID_SIZE, characterUUID},
        GATT_PERMIT_READ,
        0,
        &virtualSerialRxProps},
    // RX 特征值
    {
        {ATT_BT_UUID_SIZE, virtualSerialRxUUID},
        GATT_PERMIT_WRITE,
        0,
        virtualSerialRx},
    // TX 特征声明
    {
        {ATT_BT_UUID_SIZE, characterUUID},
        GATT_PERMIT_READ,
        0,
        &virtualSerialTxProps},
    // TX 特征值
    {
        {ATT_BT_UUID_SIZE, virtualSerialTxUUID},
        0,
        0,
        virtualSerialTx},
    // TX 特征配置
    {
        {ATT_BT_UUID_SIZE, clientCharCfgUUID},
        GATT_PERMIT_READ | GATT_PERMIT_WRITE,
        0,
        (uint8_t *)virtualSerialTxConfig},
};

static bStatus_t virtualSerial_ReadAttrCB(uint16_t connHandle, gattAttribute_t *pAttr,
                                          uint8_t *pValue, uint16_t *pLen, uint16_t offset, uint16_t maxLen, uint8_t method);
static bStatus_t virtualSerial_WriteAttrCB(uint16_t connHandle, gattAttribute_t *pAttr,
                                           uint8_t *pValue, uint16_t len, uint16_t offset, uint8_t method);
static void virtualSerial_HandleConnStatusCB(uint16_t connHandle, uint8_t changeType);

// Virtual Serial Service 的回调函数定义
gattServiceCBs_t virtualSerialCBs = {
    virtualSerial_ReadAttrCB,
    virtualSerial_WriteAttrCB,
    NULL
};

/*********************************************************************
 * @fn      VirtualSerial_AddService
 *
 * @brief   初始化 Virtual Serial 服务
 */
bStatus_t VirtualSerial_AddService(uint32_t services)
{
    uint8_t status = SUCCESS;
    GATTServApp_InitCharCfg(INVALID_CONNHANDLE, virtualSerialTxConfig);
    linkDB_Register(virtualSerial_HandleConnStatusCB);
    if(services & VIRTUALSERIAL_SERVICE)
    {
        status = GATTServApp_RegisterService(virtualSerialAttrTbl,
                                             GATT_NUM_ATTRS(virtualSerialAttrTbl),
                                             GATT_MAX_ENCRYPT_KEY_SIZE,
                                             &virtualSerialCBs);
    }
    return (status);
}

/*********************************************************************
 * @fn      VirtualSerial_RegisterAppCBs
 *
 * @brief   注册应用程序回调函数
 */
bStatus_t VirtualSerial_RegisterAppCBs(virtualSerialCBs_t *appCallbacks)
{
    if(appCallbacks)
    {
        virtualSerial_AppCBs = appCallbacks;
        return (SUCCESS);
    }
    else
    {
        return (bleAlreadyInRequestedMode);
    }
}

/*********************************************************************
 * @fn      VirtualSerial_SetParameter
 *
 * @brief   设置 Virtual Serial 参数
 */
bStatus_t VirtualSerial_SetParameter(uint8_t param, uint16_t len, void *value)
{
    bStatus_t ret = SUCCESS;
    switch(param)
    {
        case VIRTUALSERIAL_RX_CHAR:
            if(len == VIRTUALSERIAL_RX_LEN)
            {
                tmos_memcpy(virtualSerialRx, value, VIRTUALSERIAL_RX_LEN);
            }
            else
            {
                ret = bleInvalidRange;
            }
            break;
        case VIRTUALSERIAL_TX_CHAR:
            if(len == VIRTUALSERIAL_TX_LEN)
            {
                tmos_memcpy(virtualSerialTx, value, VIRTUALSERIAL_TX_LEN);
            }
            else
            {
                ret = bleInvalidRange;
            }
            break;
        default:
            ret = INVALIDPARAMETER;
            break;
    }
    return (ret);
}

/*********************************************************************
 * @fn      VirtualSerial_GetParameter
 *
 * @brief   获取 Virtual Serial 参数的值
 */
bStatus_t VirtualSerial_GetParameter(uint8_t param, void *value)
{
    bStatus_t ret = SUCCESS;
    switch(param)
    {
        case VIRTUALSERIAL_RX_CHAR:
            tmos_memcpy(value, virtualSerialRx, VIRTUALSERIAL_RX_LEN);
            break;
        case VIRTUALSERIAL_TX_CHAR:
            tmos_memcpy(value, virtualSerialTx, VIRTUALSERIAL_TX_LEN);
            break;
        default:
            ret = INVALIDPARAMETER;
            break;
    }
    return (ret);
}

/*********************************************************************
 * @fn      virtualSerial_Notify
 *
 * @brief   发送一个包含串口数据的通知
 */
bStatus_t virtualSerial_Notify(uint16_t connHandle, attHandleValueNoti_t *pNoti)
{
    uint16_t value = GATTServApp_ReadCharCfg(connHandle, virtualSerialTxConfig);
    if(value & GATT_CLIENT_CFG_NOTIFY)
    {
        pNoti->handle = virtualSerialAttrTbl[VIRTUALSERIAL_TX_VALUE_POS].handle;
        return GATT_Notification(connHandle, pNoti, FALSE);
    }
    return bleIncorrectMode;
}

/*********************************************************************
 * @fn      virtualSerial_ReadAttrCB
 *
 * @brief   读取属性回调
 */
static bStatus_t virtualSerial_ReadAttrCB(uint16_t connHandle, gattAttribute_t *pAttr,
                                          uint8_t *pValue, uint16_t *pLen, uint16_t offset, uint16_t maxLen, uint8_t method)
{
    bStatus_t status = SUCCESS;
    if(offset > 0)
    {
        return (ATT_ERR_ATTR_NOT_LONG);
    }
    if(pAttr->type.len == ATT_BT_UUID_SIZE)
    {
        uint16_t uuid = BUILD_UINT16(pAttr->type.uuid[0], pAttr->type.uuid[1]);
        switch(uuid)
        {
            default:
                *pLen = 0;
                status = ATT_ERR_ATTR_NOT_FOUND;
                break;
        }
    }
    else
    {
        *pLen = 0;
        status = ATT_ERR_INVALID_HANDLE;
    }
    return (status);
}

/*********************************************************************
 * @fn      virtualSerial_WriteAttrCB
 *
 * @brief   写属性回调
 */
static bStatus_t virtualSerial_WriteAttrCB(uint16_t connHandle, gattAttribute_t *pAttr,
                                           uint8_t *pValue, uint16_t len, uint16_t offset, uint8_t method)
{
    bStatus_t status = SUCCESS;
    uint8_t   notifyApp = 0xFF;
    
    if(gattPermitAuthorWrite(pAttr->permissions))
    {
        return (ATT_ERR_INSUFFICIENT_AUTHOR);
    }
    if(pAttr->type.len == ATT_BT_UUID_SIZE)
    {
        uint16_t uuid = BUILD_UINT16(pAttr->type.uuid[0], pAttr->type.uuid[1]);
        switch(uuid)
        {
            case VIRTUALSERIAL_RX_UUID:
                if(offset == 0)
                {
                    if(len > VIRTUALSERIAL_RX_LEN)
                    {
                        status = ATT_ERR_INVALID_VALUE_SIZE;
                    }
                }
                else
                {
                    status = ATT_ERR_ATTR_NOT_LONG;
                }
                if(status == SUCCESS)
                {
                    tmos_memcpy(pAttr->pValue, pValue, VIRTUALSERIAL_RX_LEN);
                    notifyApp = VIRTUALSERIAL_RX_CHAR;
                }
                break;
            case GATT_CLIENT_CHAR_CFG_UUID:
                status = GATTServApp_ProcessCCCWriteReq(connHandle, pAttr, pValue, len,
                                                        offset, GATT_CLIENT_CFG_NOTIFY);
                break;
            default:
                status = ATT_ERR_ATTR_NOT_FOUND;
                break;
        }
    }
    else
    {
        status = ATT_ERR_INVALID_HANDLE;
    }
    
    if((notifyApp != 0xFF) && virtualSerial_AppCBs && virtualSerial_AppCBs->pfnVirtualSerialChange)
    {
        virtualSerial_AppCBs->pfnVirtualSerialChange(notifyApp, pValue, len);
    }
    return (status);
}

/*********************************************************************
 * @fn      virtualSerial_HandleConnStatusCB
 *
 * @brief   连接状态变化处理函数
 */
static void virtualSerial_HandleConnStatusCB(uint16_t connHandle, uint8_t changeType)
{
    if(connHandle != LOOPBACK_CONNHANDLE)
    {
        if((changeType == LINKDB_STATUS_UPDATE_REMOVED) ||
           ((changeType == LINKDB_STATUS_UPDATE_STATEFLAGS) &&
            (!linkDB_Up(connHandle))))
        {
            GATTServApp_InitCharCfg(connHandle, virtualSerialTxConfig);
        }
    }
}