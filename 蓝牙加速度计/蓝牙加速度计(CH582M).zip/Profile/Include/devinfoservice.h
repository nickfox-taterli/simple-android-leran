#ifndef DEVINFOSERVICE_H
#define DEVINFOSERVICE_H

#ifdef __cplusplus
extern "C" {
#endif

// 设备信息服务的参数标识符
#define DEVINFO_SYSTEM_ID              0   // 系统 ID
#define DEVINFO_MODEL_NUMBER           1   // 型号编号
#define DEVINFO_SERIAL_NUMBER          2   // 序列号
#define DEVINFO_FIRMWARE_REV           3   // 固件版本号
#define DEVINFO_HARDWARE_REV           4   // 硬件版本号
#define DEVINFO_SOFTWARE_REV           5   // 软件版本号
#define DEVINFO_MANUFACTURER_NAME      6   // 制造商名称
#define DEVINFO_11073_CERT_DATA        7   // IEEE 11073 认证数据
#define DEVINFO_PNP_ID                 8   // 即插即用 ID

// IEEE 11073 权威机构的标识符
#define DEVINFO_11073_BODY_EMPTY       0   // 空
#define DEVINFO_11073_BODY_IEEE        1   // IEEE
#define DEVINFO_11073_BODY_CONTINUA    2   // Continua
#define DEVINFO_11073_BODY_EXP         254 // 扩展

// 系统 ID 长度
#define DEVINFO_SYSTEM_ID_LEN          8   // 系统 ID 长度

// PnP ID 长度
#define DEVINFO_PNP_ID_LEN             7   // PnP ID 长度

/*
 * DevInfo_AddService - 初始化设备信息服务，通过注册 GATT 属性到 GATT 服务器。
 *
 * @return  bStatus_t - 返回操作状态
 */
extern bStatus_t DevInfo_AddService(void);

/*
 * DevInfo_SetParameter - 设置设备信息参数。
 *
 * @param   param - 参数标识符
 * @param   len - 要写入数据的长度
 * @param   value - 指向要写入数据的指针。数据类型会根据参数标识符进行转换
 *                  (例如：uint16_t 类型的数据会被转换为 uint16_t 指针)
 *
 * @return  bStatus_t - 返回操作状态
 */
bStatus_t DevInfo_SetParameter(uint8_t param, uint16_t len, void *value);

/*
 * DevInfo_GetParameter - 获取设备信息参数。
 *
 * @param   param - 参数标识符
 * @param   value - 指向数据存储位置的指针。数据类型会根据参数标识符进行转换
 *                  (例如：uint16_t 类型的数据会被转换为 uint16_t 指针)
 *
 * @return  bStatus_t - 返回操作状态
 */
extern bStatus_t DevInfo_GetParameter(uint8_t param, void *value);

#ifdef __cplusplus
}
#endif

#endif /* DEVINFOSERVICE_H */
