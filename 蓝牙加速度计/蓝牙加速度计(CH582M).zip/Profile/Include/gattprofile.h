#ifndef GATTPROFILE_H
#define GATTPROFILE_H
#ifdef __cplusplus
extern "C" {
#endif

// Profile 参数定义
#define VIRTUALSERIAL_TX_CHAR         0           // (主机被通知)发送数据特征值
#define VIRTUALSERIAL_RX_CHAR         1           // (主机写从机)接收数据特征值

// Virtual Serial 服务 UUID
#define VIRTUALSERIAL_SERV_UUID     0xFFE0

// 各特征值 UUID
#define VIRTUALSERIAL_TX_UUID    0xFFE1
#define VIRTUALSERIAL_RX_UUID    0xFFE2

// Virtual Serial Profile 服务位字段
#define VIRTUALSERIAL_SERVICE       0x00000001

// 各特征值的长度 (默认 MTU 为 23)
#define VIRTUALSERIAL_TX_LEN     20
#define VIRTUALSERIAL_RX_LEN     256

// 特征值变化时的回调函数类型
typedef void (*virtualSerialChange_t)(uint8_t paramID, uint8_t *pValue, uint16_t len);

// Virtual Serial Profile 回调结构体
typedef struct
{
    virtualSerialChange_t pfnVirtualSerialChange; // 特征值变化时调用
} virtualSerialCBs_t;

/*********************************************************************
 * API 函数
 */

/*
 * VirtualSerial_AddService - 初始化 Virtual Serial GATT Profile 服务
 *
 * @param   services - 要添加的服务，位图形式，可以包含多个服务。
 */
extern bStatus_t VirtualSerial_AddService(uint32_t services);

/*
 * VirtualSerial_RegisterAppCBs - 注册应用程序回调函数。
 *                    该函数只需调用一次。
 *
 *    appCallbacks - 指向应用程序回调函数的指针。
 */
extern bStatus_t VirtualSerial_RegisterAppCBs(virtualSerialCBs_t *appCallbacks);

/*
 * VirtualSerial_SetParameter - 设置 Virtual Serial GATT Profile 的参数。
 *
 *    param - 配置文件参数 ID
 *    len - 数据长度
 *    value - 指向要写入数据的指针。
 */
extern bStatus_t VirtualSerial_SetParameter(uint8_t param, uint16_t len, void *value);

/*
 * VirtualSerial_GetParameter - 获取 Virtual Serial GATT Profile 的参数。
 *
 *    param - 配置文件参数 ID
 *    value - 指向数据的指针。
 */
extern bStatus_t VirtualSerial_GetParameter(uint8_t param, void *value);

/*
 * virtualSerial_Notify - 发送通知。
 *
 *    connHandle - 连接句柄
 *    pNoti - 指向通知结构体的指针。
 */
extern bStatus_t virtualSerial_Notify(uint16_t connHandle, attHandleValueNoti_t *pNoti);

#ifdef __cplusplus
}
#endif
#endif