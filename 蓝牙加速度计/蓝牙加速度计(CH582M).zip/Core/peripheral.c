#include "CONFIG.h"
#include "devinfoservice.h"
#include "gattprofile.h"
#include "peripheral.h"

#define SBP_READ_RSSI_EVT_PERIOD             3200  /**< RSSI读取事件间隔(ms) */
#define SBP_PARAM_UPDATE_DELAY               6400  /**< 参数更新延迟时间(ms) */
#define SBP_PHY_UPDATE_DELAY                 2400  /**< PHY更新延迟时间(ms) */
#define DEFAULT_ADVERTISING_INTERVAL         80    /**< 默认广播间隔(单位:0.625ms) */
#define DEFAULT_DISCOVERABLE_MODE           GAP_ADTYPE_FLAGS_GENERAL /**< 默认发现模式 */
#define DEFAULT_DESIRED_MIN_CONN_INTERVAL    6     /**< 最小连接间隔(单位:1.25ms) */
#define DEFAULT_DESIRED_MAX_CONN_INTERVAL    100   /**< 最大连接间隔(单位:1.25ms) */
#define DEFAULT_DESIRED_SLAVE_LATENCY        0     /**< 从机延迟 */
#define DEFAULT_DESIRED_CONN_TIMEOUT         100   /**< 连接超时(单位:10ms) */
#define WCH_COMPANY_ID                       0x07D7 /**< 公司标识符: WCH */

static uint8_t vuartTaskID = INVALID_TASK_ID; /**< 内部任务/事件处理的任务ID */

/** 扫描响应数据(最大31字节) */
static uint8_t scanRspData[] = {
    // 完整设备名称
    0x12, // 数据长度
    GAP_ADTYPE_LOCAL_NAME_COMPLETE,
    'S','i','m','p','l','e',' ','P','e','r','i','p','h','e','r','a','l',
    // 连接间隔范围
    0x05, // 数据长度
    GAP_ADTYPE_SLAVE_CONN_INTERVAL_RANGE,
    LO_UINT16(DEFAULT_DESIRED_MIN_CONN_INTERVAL), // 100ms
    HI_UINT16(DEFAULT_DESIRED_MIN_CONN_INTERVAL),
    LO_UINT16(DEFAULT_DESIRED_MAX_CONN_INTERVAL), // 1s
    HI_UINT16(DEFAULT_DESIRED_MAX_CONN_INTERVAL),
    // 发射功率等级
    0x02, // 数据长度
    GAP_ADTYPE_POWER_LEVEL,
    0 // 0dBm
};

/** 广播数据(最大31字节) */
static uint8_t advertData[] = {
    // 标志位
    0x02, // 数据长度
    GAP_ADTYPE_FLAGS,
    DEFAULT_DISCOVERABLE_MODE | GAP_ADTYPE_FLAGS_BREDR_NOT_SUPPORTED,
    // 服务UUID
    0x03,                  // 数据长度
    GAP_ADTYPE_16BIT_MORE, // 部分UUID
    LO_UINT16(VIRTUALSERIAL_SERV_UUID),
    HI_UINT16(VIRTUALSERIAL_SERV_UUID)
};

static uint8_t attDeviceName[GAP_DEVICE_NAME_LEN] = "Simple Peripheral"; /**< 设备名称 */
static peripheralConnItem_t peripheralConnList; /**< 连接项列表 */
static uint16_t peripheralMTU = ATT_MTU_SIZE;   /**< MTU大小 */

static void Peripheral_ProcessTMOSMsg(tmos_event_hdr_t *pMsg);
static void peripheralStateNotificationCB(gapRole_States_t newState, gapRoleEvent_t *pEvent);
static void vuartProfileChangeCB(uint8_t paramID, uint8_t *pValue, uint16_t len);
static void peripheralParamUpdateCB(uint16_t connHandle, uint16_t connInterval,
                                    uint16_t connSlaveLatency, uint16_t connTimeout);
static void peripheralInitConnItem(peripheralConnItem_t *peripheralConnList);
static void peripheralRssiCB(uint16_t connHandle, int8_t rssi);
static void peripheralChar4Notify(uint8_t *pValue, uint16_t len);

static uint16_t vuartProcessEvent(uint8_t task_id, uint16_t events);

/** GAP角色回调 */
static gapRolesCBs_t Peripheral_PeripheralCBs = {
    peripheralStateNotificationCB, /**< 状态变更回调 */
    peripheralRssiCB,             /**< RSSI读取回调 */
    peripheralParamUpdateCB       /**< 参数更新回调 */
};

/** 广播回调 */
static gapRolesBroadcasterCBs_t Broadcaster_BroadcasterCBs = {
    NULL, /**< 未使用 */
    NULL  /**< 扫描请求回调 */
};

/** 绑定管理回调 */
static gapBondCBs_t Peripheral_BondMgrCBs = {
    NULL, /**< 密码回调 */
    NULL, /**< 配对/绑定状态回调 */
    NULL  /**< OOB回调 */
};

/** 简单GATT服务回调 */
static virtualSerialCBs_t virtualSerialProfileCBs = {
    vuartProfileChangeCB /**< 特征值变更回调 */
};

/*********************************************************************
 * @fn      Peripheral_Init
 * @brief   初始化外设应用
 * @return  none
 */
void Peripheral_Init()
{
    vuartTaskID = TMOS_ProcessEventRegister(vuartProcessEvent);
    
    // 设置GAP外设角色参数
    {
        uint8_t  initial_advertising_enable = TRUE;
        uint16_t desired_min_interval = DEFAULT_DESIRED_MIN_CONN_INTERVAL;
        uint16_t desired_max_interval = DEFAULT_DESIRED_MAX_CONN_INTERVAL;
        
        GAPRole_SetParameter(GAPROLE_ADVERT_ENABLED, sizeof(uint8_t), &initial_advertising_enable);
        GAPRole_SetParameter(GAPROLE_SCAN_RSP_DATA, sizeof(scanRspData), scanRspData);
        GAPRole_SetParameter(GAPROLE_ADVERT_DATA, sizeof(advertData), advertData);
        GAPRole_SetParameter(GAPROLE_MIN_CONN_INTERVAL, sizeof(uint16_t), &desired_min_interval);
        GAPRole_SetParameter(GAPROLE_MAX_CONN_INTERVAL, sizeof(uint16_t), &desired_max_interval);
    }
    
    // 设置广播参数
    {
        uint16_t advInt = DEFAULT_ADVERTISING_INTERVAL;
        GAP_SetParamValue(TGAP_DISC_ADV_INT_MIN, advInt);
        GAP_SetParamValue(TGAP_DISC_ADV_INT_MAX, advInt);
        GAP_SetParamValue(TGAP_ADV_SCAN_REQ_NOTIFY, ENABLE);
    }
    
    // 设置绑定管理参数
    {
        uint32_t passkey = 0; // 密码"000000"
        uint8_t  pairMode = GAPBOND_PAIRING_MODE_WAIT_FOR_REQ;
        uint8_t  mitm = TRUE;
        uint8_t  bonding = TRUE;
        uint8_t  ioCap = GAPBOND_IO_CAP_DISPLAY_ONLY;
        
        GAPBondMgr_SetParameter(GAPBOND_PERI_DEFAULT_PASSCODE, sizeof(uint32_t), &passkey);
        GAPBondMgr_SetParameter(GAPBOND_PERI_PAIRING_MODE, sizeof(uint8_t), &pairMode);
        GAPBondMgr_SetParameter(GAPBOND_PERI_MITM_PROTECTION, sizeof(uint8_t), &mitm);
        GAPBondMgr_SetParameter(GAPBOND_PERI_IO_CAPABILITIES, sizeof(uint8_t), &ioCap);
        GAPBondMgr_SetParameter(GAPBOND_PERI_BONDING_ENABLED, sizeof(uint8_t), &bonding);
    }
    
    // 初始化GATT服务
    GGS_AddService(GATT_ALL_SERVICES);           // GAP服务
    GATTServApp_AddService(GATT_ALL_SERVICES);   // GATT属性
    DevInfo_AddService();                        // 设备信息服务
    VirtualSerial_AddService(GATT_ALL_SERVICES); // 简单GATT服务
    
    // 设置GAP特征值
    GGS_SetParameter(GGS_DEVICE_NAME_ATT, sizeof(attDeviceName), attDeviceName);
    
    // 设置简单GATT服务特征值
    {
        uint8_t charValue3[VIRTUALSERIAL_TX_LEN] = {3};
        uint8_t charValue4[VIRTUALSERIAL_RX_LEN] = {4};
        
        VirtualSerial_SetParameter(VIRTUALSERIAL_TX_CHAR, VIRTUALSERIAL_TX_LEN, charValue3);
        VirtualSerial_SetParameter(VIRTUALSERIAL_RX_CHAR, VIRTUALSERIAL_RX_LEN, charValue4);
    }
    
    // 初始化连接项
    peripheralInitConnItem(&peripheralConnList);
    
    // 注册回调
    VirtualSerial_RegisterAppCBs(&virtualSerialProfileCBs);
    GAPRole_BroadcasterSetCB(&Broadcaster_BroadcasterCBs);
    
    // 启动设备
    tmos_set_event(vuartTaskID, SBP_START_DEVICE_EVT);
}

/*********************************************************************
 * @fn      peripheralInitConnItem
 * @brief   初始化连接项
 * @param   peripheralConnList - 连接项指针
 * @return  none
 */
static void peripheralInitConnItem(peripheralConnItem_t *peripheralConnList)
{
    peripheralConnList->connHandle = GAP_CONNHANDLE_INIT;
    peripheralConnList->connInterval = 0;
    peripheralConnList->connSlaveLatency = 0;
    peripheralConnList->connTimeout = 0;
}

/*********************************************************************
 * @fn      vuartProcessEvent
 * @brief   外设任务事件处理
 * @param   task_id - 任务ID
 * @param   events - 事件
 * @return  未处理的事件
 */
static uint16_t vuartProcessEvent(uint8_t task_id, uint16_t events)
{
    uint8_t *pMsg;

    if(events & SYS_EVENT_MSG)
    {
        if((pMsg = tmos_msg_receive(vuartTaskID)) != NULL)
        {
            Peripheral_ProcessTMOSMsg((tmos_event_hdr_t *)pMsg);
            tmos_msg_deallocate(pMsg);
        }
        return (events ^ SYS_EVENT_MSG);
    }
    
    if(events & SBP_START_DEVICE_EVT)
    {
        GAPRole_PeripheralStartDevice(vuartTaskID, &Peripheral_BondMgrCBs, &Peripheral_PeripheralCBs);
        return (events ^ SBP_START_DEVICE_EVT);
    }
    
    if(events & SBP_PARAM_UPDATE_EVT)
    {
        GAPRole_PeripheralConnParamUpdateReq(peripheralConnList.connHandle,
                                             DEFAULT_DESIRED_MIN_CONN_INTERVAL,
                                             DEFAULT_DESIRED_MAX_CONN_INTERVAL,
                                             DEFAULT_DESIRED_SLAVE_LATENCY,
                                             DEFAULT_DESIRED_CONN_TIMEOUT,
                                             vuartTaskID);
        return (events ^ SBP_PARAM_UPDATE_EVT);
    }
    
    if(events & SBP_PHY_UPDATE_EVT)
    {
        PRINT("PHY Update %x...\r\n", GAPRole_UpdatePHY(peripheralConnList.connHandle, 0, 
                    GAP_PHY_BIT_LE_2M, GAP_PHY_BIT_LE_2M, GAP_PHY_OPTIONS_NOPRE));
        return (events ^ SBP_PHY_UPDATE_EVT);
    }
    
    if(events & SBP_READ_RSSI_EVT)
    {
        GAPRole_ReadRssiCmd(peripheralConnList.connHandle);
        tmos_start_task(vuartTaskID, SBP_READ_RSSI_EVT, SBP_READ_RSSI_EVT_PERIOD);
        return (events ^ SBP_READ_RSSI_EVT);
    }
    
    return 0;
}

/*********************************************************************
 * @fn      Peripheral_ProcessGAPMsg
 * @brief   处理GAP消息
 * @param   pEvent - GAP事件指针
 * @return  none
 */
static void Peripheral_ProcessGAPMsg(gapRoleEvent_t *pEvent)
{
    switch(pEvent->gap.opcode)
    {
        case GAP_SCAN_REQUEST_EVENT:
            PRINT("SCAN REQ [%x:%x:%x:%x:%x:%x]  ..\r\n", pEvent->scanReqEvt.scannerAddr[0],
                  pEvent->scanReqEvt.scannerAddr[1], pEvent->scanReqEvt.scannerAddr[2], pEvent->scanReqEvt.scannerAddr[3],
                  pEvent->scanReqEvt.scannerAddr[4], pEvent->scanReqEvt.scannerAddr[5]);
            break;
            
        case GAP_PHY_UPDATE_EVENT:
            PRINT("PHY UPDATE Rx:%x Tx:%x ..\r\n", pEvent->linkPhyUpdate.connRxPHYS, pEvent->linkPhyUpdate.connTxPHYS);
            break;
            
        default:
            break;
    }
}

/*********************************************************************
 * @fn      Peripheral_ProcessTMOSMsg
 * @brief   处理TMOS消息
 * @param   pMsg - 消息指针
 * @return  none
 */
static void Peripheral_ProcessTMOSMsg(tmos_event_hdr_t *pMsg)
{
    switch(pMsg->event)
    {
        case GAP_MSG_EVENT:
            Peripheral_ProcessGAPMsg((gapRoleEvent_t *)pMsg);
            break;
            
        case GATT_MSG_EVENT:
        {
            gattMsgEvent_t *pMsgEvent = (gattMsgEvent_t *)pMsg;
            if(pMsgEvent->method == ATT_MTU_UPDATED_EVENT)
            {
                peripheralMTU = pMsgEvent->msg.exchangeMTUReq.clientRxMTU;
                // PRINT("MTU = %d\r\n", pMsgEvent->msg.exchangeMTUReq.clientRxMTU);
            }
            break;
        }

        PRINT("MTU = %d\r\n", peripheralMTU);
            
        default:
            break;
    }
}

/*********************************************************************
 * @fn      Peripheral_LinkEstablished
 * @brief   连接建立处理
 * @param   pEvent - GAP事件指针
 * @return  none
 */
static void Peripheral_LinkEstablished(gapRoleEvent_t *pEvent)
{
    gapEstLinkReqEvent_t *event = (gapEstLinkReqEvent_t *)pEvent;
    
    if(peripheralConnList.connHandle != GAP_CONNHANDLE_INIT)
    {
        GAPRole_TerminateLink(pEvent->linkCmpl.connectionHandle);
        PRINT("Connection max...\r\n");
    }
    else
    {
        peripheralConnList.connHandle = event->connectionHandle;
        peripheralConnList.connInterval = event->connInterval;
        peripheralConnList.connSlaveLatency = event->connLatency;
        peripheralConnList.connTimeout = event->connTimeout;
        peripheralMTU = ATT_MTU_SIZE;

        // 周期性更新连接参数
        tmos_start_task(vuartTaskID, SBP_PARAM_UPDATE_EVT, SBP_PARAM_UPDATE_DELAY);
        
        // 周期性读取信号
        // tmos_start_task(vuartTaskID, SBP_READ_RSSI_EVT, SBP_READ_RSSI_EVT_PERIOD);
        
        PRINT("Conn %x - Int %x \r\n", event->connectionHandle, event->connInterval);
    }
}

/*********************************************************************
 * @fn      Peripheral_LinkTerminated
 * @brief   连接终止处理
 * @param   pEvent - GAP事件指针
 * @return  none
 */
static void Peripheral_LinkTerminated(gapRoleEvent_t *pEvent)
{
    gapTerminateLinkEvent_t *event = (gapTerminateLinkEvent_t *)pEvent;
    
    if(event->connectionHandle == peripheralConnList.connHandle)
    {
        peripheralConnList.connHandle = GAP_CONNHANDLE_INIT;
        peripheralConnList.connInterval = 0;
        peripheralConnList.connSlaveLatency = 0;
        peripheralConnList.connTimeout = 0;
        
        tmos_stop_task(vuartTaskID, SBP_READ_RSSI_EVT);
        
        // 重新开始广播
        uint8_t advertising_enable = TRUE;
        GAPRole_SetParameter(GAPROLE_ADVERT_ENABLED, sizeof(uint8_t), &advertising_enable);
    }
    else
    {
        PRINT("ERR..\r\n");
    }
}

/*********************************************************************
 * @fn      peripheralRssiCB
 * @brief   RSSI回调
 * @param   connHandle - 连接句柄
 * @param   rssi - RSSI值
 * @return  none
 */
static void peripheralRssiCB(uint16_t connHandle, int8_t rssi)
{
    PRINT("RSSI -%d dB Conn  %x \r\n", -rssi, connHandle);
}

/*********************************************************************
 * @fn      peripheralParamUpdateCB
 * @brief   参数更新回调
 * @param   connHandle - 连接句柄
 * @param   connInterval - 连接间隔
 * @param   connSlaveLatency - 从机延迟
 * @param   connTimeout - 连接超时
 * @return  none
 */
static void peripheralParamUpdateCB(uint16_t connHandle, uint16_t connInterval,
                                    uint16_t connSlaveLatency, uint16_t connTimeout)
{
    if(connHandle == peripheralConnList.connHandle)
    {
        peripheralConnList.connInterval = connInterval;
        peripheralConnList.connSlaveLatency = connSlaveLatency;
        peripheralConnList.connTimeout = connTimeout;
        PRINT("Update %x - Int %x \r\n", connHandle, connInterval);
    }
    else
    {
        PRINT("ERR..\r\n");
    }
}

/*********************************************************************
 * @fn      peripheralStateNotificationCB
 * @brief   状态通知回调
 * @param   newState - 新状态
 * @param   pEvent - GAP事件指针
 * @return  none
 */
static void peripheralStateNotificationCB(gapRole_States_t newState, gapRoleEvent_t *pEvent)
{
    switch(newState & GAPROLE_STATE_ADV_MASK)
    {
        case GAPROLE_STARTED:
            PRINT("Initialized..\r\n");
            break;
            
        case GAPROLE_ADVERTISING:
            if(pEvent->gap.opcode == GAP_LINK_TERMINATED_EVENT)
            {
                Peripheral_LinkTerminated(pEvent);
                PRINT("Disconnected.. Reason:%x\n", pEvent->linkTerminate.reason);
                PRINT("Advertising..\r\n");
            }
            else if(pEvent->gap.opcode == GAP_MAKE_DISCOVERABLE_DONE_EVENT)
            {
                PRINT("Advertising..\r\n");
            }
            break;
            
        case GAPROLE_CONNECTED:
            if(pEvent->gap.opcode == GAP_LINK_ESTABLISHED_EVENT)
            {
                Peripheral_LinkEstablished(pEvent);
                PRINT("Connected..\r\n");
            }
            break;
            
        case GAPROLE_CONNECTED_ADV:
            if(pEvent->gap.opcode == GAP_MAKE_DISCOVERABLE_DONE_EVENT)
            {
                PRINT("Connected Advertising..\r\n");
            }
            break;
            
        case GAPROLE_WAITING:
            if(pEvent->gap.opcode == GAP_END_DISCOVERABLE_DONE_EVENT)
            {
                PRINT("Waiting for advertising..\r\n");
            }
            else if(pEvent->gap.opcode == GAP_LINK_TERMINATED_EVENT)
            {
                Peripheral_LinkTerminated(pEvent);
                PRINT("Disconnected.. Reason:%x\n", pEvent->linkTerminate.reason);
            }
            else if(pEvent->gap.opcode == GAP_LINK_ESTABLISHED_EVENT)
            {
                if(pEvent->gap.hdr.status != SUCCESS)
                {
                    PRINT("Waiting for advertising..\r\n");
                }
                else
                {
                    PRINT("Error..\r\n");
                }
            }
            else
            {
                PRINT("Error..%x\n", pEvent->gap.opcode);
            }
            break;
            
        case GAPROLE_ERROR:
            PRINT("Error..\r\n");
            break;
            
        default:
            break;
    }
}

/*********************************************************************
 * @fn      vuartNotifyData
 * @brief   发送特征通知
 * @param   pValue - 数据指针
 * @param   len - 数据长度
 * @return  none
 */
void vuartNotifyData(uint8_t *pValue, uint16_t len)
{
    attHandleValueNoti_t noti;
    
    if(len > (peripheralMTU - 3))
    {
        PRINT("Too large noti,len = %d,mtu = %d\r\n",len,peripheralMTU);
        return;
    }
    
    noti.len = len;
    noti.pValue = GATT_bm_alloc(peripheralConnList.connHandle, ATT_HANDLE_VALUE_NOTI, noti.len, NULL, 0);
    
    if(noti.pValue)
    {
        tmos_memcpy(noti.pValue, pValue, noti.len);
        if(virtualSerial_Notify(peripheralConnList.connHandle, &noti) != SUCCESS)
        {
            GATT_bm_free((gattMsg_t *)&noti, ATT_HANDLE_VALUE_NOTI);
        }
    }
}

/*********************************************************************
 * @fn      vuartProfileChangeCB
 * @brief   简单GATT服务特征值变更回调
 * @param   paramID - 特征ID
 * @param   pValue - 数据指针
 * @param   len - 数据长度
 * @return  none
 */
static void vuartProfileChangeCB(uint8_t paramID, uint8_t *pValue, uint16_t len)
{
    switch(paramID)
    {
        case VIRTUALSERIAL_RX_CHAR:
        {
            // 这里处理接收的结果
            uint8_t newValue[VIRTUALSERIAL_TX_LEN];
            tmos_memcpy(newValue, pValue, len);
            PRINT("newValue = %s\r\n",newValue);
            break;
        }
            
        default:
            break;
    }
}