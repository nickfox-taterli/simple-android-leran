#ifndef PERIPHERAL_H
#define PERIPHERAL_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup peripheral_events 外设任务事件定义
 * @{
 */
#define SBP_START_DEVICE_EVT    0x0001  /**< 启动设备事件 */
#define SBP_READ_RSSI_EVT       0x0002  /**< 读取RSSI事件 */
#define SBP_PARAM_UPDATE_EVT    0x0004  /**< 参数更新事件 */
#define SBP_PHY_UPDATE_EVT      0x0008  /**< PHY更新事件 */
/** @} */

/**
 * @brief 外设连接参数结构体
 * 
 * 用于存储当前BLE连接的参数信息
 */
typedef struct
{
    uint16_t connHandle;     /**< 当前连接的句柄 */
    uint16_t connInterval;   /**< 连接间隔，单位：1.25ms */
    uint16_t connSlaveLatency; /**< 连接从机延迟，单位：连接事件数 */
    uint16_t connTimeout;    /**< 连接超时时间，单位：10ms */
} peripheralConnItem_t;

/*********************************************************************
 * @brief 外设模块函数接口
 */

/**
 * @brief 初始化BLE外设任务
 * 
 * 该函数用于初始化BLE外设应用任务，创建任务并初始化相关硬件
 */
void Peripheral_Init(void);
void vuartNotifyData(uint8_t *pValue, uint16_t len);

#ifdef __cplusplus
}
#endif

#endif /* PERIPHERAL_H */