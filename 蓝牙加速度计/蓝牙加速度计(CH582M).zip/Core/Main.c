#include "CONFIG.h"
#include "HAL.h"
#include "gattprofile.h"
#include "peripheral.h"

extern void SensorTask_Init(void);

/** 
 * @brief BLE内存堆空间
 * @note 以4字节对齐方式分配内存，大小为BLE_MEMHEAP_SIZE
 */
__attribute__ ((aligned (4))) uint32_t MEM_BUF[BLE_MEMHEAP_SIZE / 4];

#if (defined(BLE_MAC)) && (BLE_MAC == TRUE)
/**
 * @brief BLE设备MAC地址
 * @note 默认MAC地址为84:C2:E4:03:02:02
 */
const uint8_t MacAddr[6] = {0x84, 0xC2, 0xE4, 0x03, 0x02, 0x02};
#endif

/**
 * @brief 主循环函数
 * @details 执行TMOS系统处理任务
 * @note 1. 使用__HIGH_CODE宏指定函数在高速区域执行  
 *       2. 使用noinline属性禁止函数内联优化
 */
__HIGH_CODE __attribute__ ((noinline)) void loop() {
    while (1) {
        TMOS_SystemProcess();  ///< 执行TMOS系统任务
    }
}

/**
 * @brief 程序主入口
 * @details 完成系统时钟、外设、BLE协议栈的初始化
 * @return int 程序返回值（实际不会返回）
 */
int main (void)
{
#if (defined(DCDC_ENABLE)) && (DCDC_ENABLE == TRUE)
    PWR_DCDCCfg (ENABLE);  ///< 使能DCDC电源转换
#endif
    
    SetSysClock (CLK_SOURCE_PLL_80MHz);  ///< 设置系统时钟为80MHz PLL
    
#if (defined(HAL_SLEEP)) && (HAL_SLEEP == TRUE)
    /* 配置所有GPIO为上拉输入模式以降低睡眠模式功耗 */
    GPIOA_ModeCfg (GPIO_Pin_All, GPIO_ModeIN_PU);
    GPIOB_ModeCfg (GPIO_Pin_All, GPIO_ModeIN_PU);
#endif

#ifdef DEBUG
    /* 调试串口初始化 */
    GPIOA_SetBits (bTXD1);
    GPIOA_ModeCfg (bTXD1, GPIO_ModeOut_PP_5mA);
    UART1_DefInit();
    PRINT ("%s\r\n", VER_LIB);  ///< 打印库版本信息
#endif

    CH58X_BLEInit();        ///< BLE协议栈初始化
    HAL_Init();             ///< 硬件抽象层初始化
    GAPRole_PeripheralInit();  ///< GAP外设角色初始化
    Peripheral_Init();      ///< 应用外设初始化
        
    SensorTask_Init();

    loop();  ///< 进入主循环
    
    return 0;
}
