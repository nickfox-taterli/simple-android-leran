#include "HAL.h"

/*******************************************************************************
 * @fn      CH58X_LowPower
 * @brief   启动睡眠流程
 * @param   time - 唤醒的RTC时间点（绝对值）
 * @return  状态码：0-成功进入睡眠，2-睡眠时间无效，3-已被唤醒
 ******************************************************************************/
uint32_t CH58X_LowPower(uint32_t time)
{
#if (defined(HAL_SLEEP)) && (HAL_SLEEP == TRUE)
    uint32_t time_sleep, time_curr;
    unsigned long irq_status;

    SYS_DisableAllIrq(&irq_status);               // 关闭中断，防止临界区被打断
    time_curr = RTC_GetCycle32k();                // 获取当前RTC计数器值

    // 计算距离唤醒时间还有多久（考虑计数器回绕）
    if (time < time_curr) {
        time_sleep = time + (RTC_TIMER_MAX_VALUE - time_curr);
    } else {
        time_sleep = time - time_curr;
    }

    // 判断是否满足进入睡眠的时间要求
    if ((time_sleep < SLEEP_RTC_MIN_TIME) || 
        (time_sleep > SLEEP_RTC_MAX_TIME)) {
        SYS_RecoverIrq(irq_status);               // 恢复中断
        return 2;                                  // 时间不合法，不进入睡眠
    }

    RTC_SetTignTime(time);                        // 设置RTC唤醒时间
    SYS_RecoverIrq(irq_status);                   // 恢复中断

#if (DEBUG == Debug_UART1)
    // 等待UART1发送缓冲区清空，避免睡眠中断串口发送
    while ((R8_UART1_LSR & RB_LSR_TX_ALL_EMP) == 0) {
        __nop();
    }
#endif

    // 若尚未被唤醒，进入低功耗sleep模式
    if (!RTCTigFlag) {
        LowPower_Sleep(RB_PWR_RAM2K | RB_PWR_RAM30K | RB_PWR_EXTEND); // 睡眠，保留RAM

        // 如果是由RTC以外的方式唤醒（如外部IO），需要重新配置进入Idle模式
        if (RTCTigFlag) {
            time += WAKE_UP_RTC_MAX_TIME;         // 预留晶振启动时间
            if (time > 0xA8C00000) {
                time -= 0xA8C00000;
            }
            RTC_SetTignTime(time);                // 再次设置唤醒时间
            LowPower_Idle();                      // 进入Idle模式等待晶振稳定
        }

        HSECFG_Current(HSE_RCur_100);             // 恢复HSE电流配置（降低功耗）
    } else {
        return 3;                                  // 已唤醒，不再进入睡眠
    }
#endif
    return 0;                                      // 正常进入睡眠并返回
}

/*******************************************************************************
 * @fn      HAL_SleepInit
 * @brief   初始化睡眠唤醒方式：启用RTC唤醒并设置为触发模式
 * @param   None
 * @return  None
 ******************************************************************************/
void HAL_SleepInit(void)
{
#if (defined(HAL_SLEEP)) && (HAL_SLEEP == TRUE)
    sys_safe_access_enable();
    R8_SLP_WAKE_CTRL |= RB_SLP_RTC_WAKE;          // 允许RTC唤醒
    sys_safe_access_disable();

    sys_safe_access_enable();
    R8_RTC_MODE_CTRL |= RB_RTC_TRIG_EN;           // 设置为RTC触发模式
    sys_safe_access_disable();

    PFIC_EnableIRQ(RTC_IRQn);                     // 启用RTC中断
#endif
}
