#include "HAL.h"
#include "CH58x_common.h"
#include "peripheral.h"

#include "stdbool.h"

// 因为TMOS限制,每次也就只能取走部分数据,所以缓冲再大也没用.
#define I2C_BUFFER_LENGTH 20
#define I2C_READ          1
#define I2C_WRITE         0

// MPU6050 7-bit 地址，一般是 0x68（AD0 接地）
#define MPU6050_ADDR        0x68

// 寄存器地址 (MPU6050)
#define REG_PWR_MGMT_1      0x6B
#define REG_SMPLRT_DIV      0x19
#define REG_CONFIG          0x1A
#define REG_GYRO_CONFIG     0x1B
#define REG_ACCEL_CONFIG    0x1C
#define REG_ACCEL_XOUT_H    0x3B

typedef enum {
    I2C_READY,
    I2C_MRX,  
    I2C_MTX,  
    I2C_SRX,  
    I2C_STX,  
}i2c_state_t;

typedef enum {
    I2C_NO_MEM = 1,
    I2C_STATE,
    I2C_MT_NACK,
    I2C_ARB_LOST,
    I2C_BUS_ERROR,
    I2C_OVR,
    I2C_PECERR,
    I2C_TIMEOUT,
    I2C_SMBALERT,
}i2c_error_t;

static tmosTaskID sensorTaskID;

// I2C状态变量
static volatile uint8_t i2c_state;
static volatile uint8_t i2c_slave_addr_rw;  // 从设备地址及读写位
static volatile uint8_t i2c_send_stop;      // 是否在事务结束时发送STOP信号
static volatile uint8_t i2c_in_repstart;    // 是否处于重复开始状态

// 主模式缓冲区
static uint8_t i2c_master_buffer[I2C_BUFFER_LENGTH];
static volatile uint8_t i2c_master_buffer_index;
static uint8_t i2c_master_buffer_length;

// 从模式发送缓冲区
static uint8_t i2c_slave_txbuffer[I2C_BUFFER_LENGTH];
static volatile uint8_t i2c_slave_txbuffer_index;
static uint8_t i2c_slave_txbuffer_length;

// 从模式接收缓冲区
static uint8_t i2c_slave_rxbuffer[I2C_BUFFER_LENGTH];
static volatile uint8_t i2c_slave_rxbuffer_index;

static uint8_t is_nack_sent = false;        // 是否已发送NACK
static volatile uint8_t i2c_error;          // I2C错误标志

// I2C初始化函数
static void I2C_App_Init(uint8_t address)
{
    i2c_state = I2C_READY;
    i2c_send_stop = true;
    i2c_in_repstart = false;

    // 配置I2C引脚为上拉输入模式
    GPIOB_ModeCfg(GPIO_Pin_13 | GPIO_Pin_12, GPIO_ModeIN_PU);

    // 初始化I2C外设
    I2C_Init(I2C_Mode_I2C, 400000, I2C_DutyCycle_16_9, I2C_Ack_Enable,
            I2C_AckAddr_7bit, address);

    // 使能I2C中断
    I2C_ITConfig(I2C_IT_BUF, ENABLE);
    I2C_ITConfig(I2C_IT_EVT, ENABLE);
    I2C_ITConfig(I2C_IT_ERR, ENABLE);
    
    // 使能I2C中断向量
    PFIC_EnableIRQ(I2C_IRQn);
}

// I2C写数据函数
static int I2C_Write(uint8_t addr_7bit, const uint8_t *data, uint8_t length,uint8_t wait, uint8_t send_stop)
{
    if (length > I2C_BUFFER_LENGTH) {
        return -I2C_NO_MEM;  // 缓冲区不足
    }

    if (i2c_state != I2C_READY) {
        return -I2C_STATE;   // I2C忙状态
    }

    if (!length) {
        return 0;           // 长度为0直接返回
    }

    i2c_state = I2C_MTX;    // 设置为主发送模式
    i2c_send_stop = send_stop;
    i2c_error = 0;

    // 初始化缓冲区索引
    i2c_master_buffer_index = 0;
    i2c_master_buffer_length = length;

    // 复制数据到发送缓冲区
    memcpy(i2c_master_buffer, data, length);

    // 设置从设备地址和写标志
    i2c_slave_addr_rw = I2C_WRITE;
    i2c_slave_addr_rw |= addr_7bit << 1;

    I2C_GenerateSTOP(DISABLE);

    if (i2c_in_repstart == true) {
        i2c_in_repstart = false;

        // 在重复开始状态下发送地址
        do {
            I2C_SendData(i2c_slave_addr_rw);
        } while(R16_I2C_STAR1 & RB_I2C_BTF);

        // 重新使能中断
        I2C_ITConfig(I2C_IT_BUF, ENABLE);
        I2C_ITConfig(I2C_IT_EVT, ENABLE);
        I2C_ITConfig(I2C_IT_ERR, ENABLE);
    } else {
        // 生成START信号
        I2C_GenerateSTART(ENABLE);
    }

    // 等待传输完成
    while(wait && (i2c_state == I2C_MTX)) {
        continue;
    }

    if (i2c_error) {
        return -i2c_error;  // 返回错误码
    }

    return 0;  // 成功返回
}

// I2C读数据函数
static int I2C_Read(uint8_t addr_7bit, uint8_t *data, uint8_t length,uint8_t send_stop)
{
    int to = 0;
    if (length > I2C_BUFFER_LENGTH) {
        return -I2C_NO_MEM;  // 缓冲区不足
    }

    if (i2c_state != I2C_READY) {
        return -I2C_STATE;   // I2C忙状态
    }

    if (!length) {
        return 0;           // 长度为0直接返回
    }

    i2c_state = I2C_MRX;    // 设置为主接收模式
    i2c_send_stop = send_stop;
    i2c_error = 0;

    // 初始化缓冲区索引
    i2c_master_buffer_index = 0;
    i2c_master_buffer_length = length - 1;  // 最后一个字节需要特殊处理

    // 设置从设备地址和读标志
    i2c_slave_addr_rw = I2C_READ;
    i2c_slave_addr_rw |= addr_7bit << 1;

    I2C_GenerateSTOP(DISABLE);

    if (i2c_in_repstart == true) {
        i2c_in_repstart = false;

        // 在重复开始状态下发送地址
        do {
            I2C_SendData(i2c_slave_addr_rw);
        } while(R16_I2C_STAR1 & RB_I2C_BTF);

        // 重新使能中断
        I2C_ITConfig(I2C_IT_BUF, ENABLE);
        I2C_ITConfig(I2C_IT_EVT, ENABLE);
        I2C_ITConfig(I2C_IT_ERR, ENABLE);
    } else {
        // 生成START信号
        I2C_GenerateSTART(ENABLE);
    }

    // 等待读取完成
    while (i2c_state == I2C_MRX) {
    }

    // 确保不越界
    if (i2c_master_buffer_index < length)
        length = i2c_master_buffer_index;

    // 复制数据到输出缓冲区
    memcpy(data, i2c_master_buffer, length);

    return length;  // 返回实际读取长度
}

// I2C中断处理函数
__INTERRUPT __HIGH_CODE void I2C_IRQHandler(void)
{
    uint32_t event = I2C_GetLastEvent();

    /* 主模式处理 */
    if (event & (RB_I2C_MSL << 16)) {
        if (event & RB_I2C_SB) {
            /* 开始条件已发送，发送地址 */
            I2C_SendData(i2c_slave_addr_rw);
        }

        /* 主发送模式 */
        if (event & (RB_I2C_TRA << 16)) {
            /* 从设备已应答地址或发送位 */
            if (event & (RB_I2C_ADDR | RB_I2C_BTF | RB_I2C_TxE | (RB_I2C_TRA << 16))) {
                /* 如果有数据要发送，发送它，否则停止 */
                if (i2c_master_buffer_index < i2c_master_buffer_length) {
                    I2C_SendData(i2c_master_buffer[i2c_master_buffer_index++]);
                } else {
                    if (i2c_send_stop) {
                        i2c_state = I2C_READY;
                        I2C_GenerateSTOP(ENABLE);
                    } else {
                        i2c_in_repstart = true;
                        /* 将要发送START，不使能中断 */
                        I2C_ITConfig(I2C_IT_BUF, DISABLE);
                        I2C_ITConfig(I2C_IT_EVT, DISABLE);
                        I2C_ITConfig(I2C_IT_ERR, DISABLE);
                        I2C_GenerateSTART(ENABLE);
                        i2c_state = I2C_READY;
                    }
                }
            }

            /* 地址或数据已发送，收到NACK */
            if (event & RB_I2C_AF) {
                I2C_ClearFlag(I2C_FLAG_AF);

                i2c_error = I2C_MT_NACK;
                i2c_state = I2C_READY;
                I2C_GenerateSTOP(ENABLE);
            }
        } else {
        /* 主接收模式 */
            /* 地址已发送，收到ACK */
            if(event & RB_I2C_ADDR) { 
                /* 如果期待更多字节，发送ACK，否则发送NACK */
                if (i2c_master_buffer_length) {
                    I2C_AcknowledgeConfig(ENABLE);
                } else {
                    I2C_AcknowledgeConfig(DISABLE);
                    is_nack_sent = true;
                }
            }

            /* 数据已接收 */
            if (event & (RB_I2C_RxNE)) {
                /* 将字节存入缓冲区 */ 
                i2c_master_buffer[i2c_master_buffer_index++] = I2C_ReceiveData();

                if (i2c_master_buffer_index < i2c_master_buffer_length) {
                    I2C_AcknowledgeConfig(ENABLE);
                } else {
                    I2C_AcknowledgeConfig(DISABLE);

                    if (is_nack_sent) {
                        is_nack_sent = false;
                        if (i2c_send_stop) {
                            I2C_GenerateSTOP(ENABLE);
                            i2c_state = I2C_READY;
                        } else {
                            i2c_in_repstart = true;
                            /* 将要发送START，不使能中断 */
                            I2C_ITConfig(I2C_IT_BUF, DISABLE);
                            I2C_ITConfig(I2C_IT_EVT, DISABLE);
                            I2C_ITConfig(I2C_IT_ERR, DISABLE);
                            I2C_GenerateSTART(ENABLE);
                            i2c_state = I2C_READY;
                        }
                    } else {
                        is_nack_sent = true;
                    }
                }
            }

            /* 收到NACK */
            if (event & RB_I2C_AF) {
                I2C_ClearFlag(I2C_FLAG_AF);
                /* 将最后一个字节存入缓冲区 */
                i2c_master_buffer[i2c_master_buffer_index++] = I2C_ReceiveData();

                if (i2c_send_stop) {
                    i2c_state = I2C_READY;
                    I2C_GenerateSTOP(ENABLE);
                } else {
                    i2c_in_repstart = true;
                    /* 将要发送START，不使能中断 */
                    I2C_ITConfig(I2C_IT_BUF, DISABLE);
                    I2C_ITConfig(I2C_IT_EVT, DISABLE);
                    I2C_ITConfig(I2C_IT_ERR, DISABLE);
                    I2C_GenerateSTART(ENABLE);
                    i2c_state = I2C_READY;
                }
            }
        }

    } else {
    /* 从模式处理 */
        /* 地址匹配，已返回ACK */
        if (event & RB_I2C_ADDR) {
            if (event & ((RB_I2C_TRA << 16) | RB_I2C_TxE)) {
                /* 从发送模式地址匹配 */
                i2c_state = I2C_STX;
                i2c_slave_txbuffer_index = 0;
                i2c_slave_txbuffer_length = 0;
            } else {
                /* 从接收模式地址匹配 */
                i2c_state = I2C_SRX;
                i2c_slave_rxbuffer_index = 0;
            }
        }

        if (event & (RB_I2C_TRA << 16)) {
            /* 从发送模式 */
            I2C_AcknowledgeConfig(ENABLE);

            if (event & RB_I2C_AF) {
                /* 收到NACK */
                I2C_ClearFlag(I2C_FLAG_AF);
                I2C_AcknowledgeConfig(ENABLE);

                /* 离开从接收状态 */
                i2c_state = I2C_READY;
                /* 清除状态 */
                event = 0;
            }

            if (event & (RB_I2C_BTF | RB_I2C_TxE)) {
                /* 如果有更多数据要发送，发送它，否则发送0xff */
                if (i2c_slave_txbuffer_index < i2c_slave_txbuffer_length) {
                    I2C_SendData(i2c_slave_txbuffer[i2c_slave_txbuffer_index++]);
                } else {
                    I2C_SendData(0xff);
                }
            }
        } else {
            /* 从接收模式 */
            if (event & RB_I2C_RxNE) {
                /* 如果接收缓冲区还有空间 */
                if (i2c_slave_rxbuffer_index < I2C_BUFFER_LENGTH) {
                    /* 存入缓冲区并发送ACK */
                    i2c_slave_rxbuffer[i2c_slave_rxbuffer_index++] = I2C_ReceiveData();
                    I2C_AcknowledgeConfig(ENABLE);
                } else {
                    // 否则发送NACK
                    I2C_AcknowledgeConfig(DISABLE);
                }
            }

            if (event & RB_I2C_STOPF) {
                /* 清除STOP标志 */
                R16_I2C_CTRL1 |= RB_I2C_PE;

                /* 重置接收缓冲区索引 */
                i2c_slave_rxbuffer_index = 0;
            }

            if (event & RB_I2C_AF) {  
                I2C_ClearFlag(I2C_FLAG_AF);
                I2C_AcknowledgeConfig(ENABLE);
            }
        }
    }

    /* 错误处理 */
    if (event & RB_I2C_BERR) {
        I2C_ClearFlag(RB_I2C_BERR);
        I2C_GenerateSTOP(ENABLE);
        i2c_error = I2C_BUS_ERROR;
    }

    if (event & RB_I2C_ARLO) {
        I2C_ClearFlag(RB_I2C_ARLO);
        i2c_error = I2C_ARB_LOST;
    }

    if (event & RB_I2C_OVR) {
        I2C_ClearFlag(RB_I2C_OVR);
        i2c_error = I2C_OVR;
    }

    if (event & RB_I2C_PECERR) {
        I2C_ClearFlag(RB_I2C_PECERR);
        i2c_error = I2C_PECERR;
    }

    if (event & RB_I2C_TIMEOUT) {
        I2C_ClearFlag(RB_I2C_TIMEOUT);
        i2c_error = I2C_TIMEOUT;
    }

    if (event & RB_I2C_SMBALERT) {
        I2C_ClearFlag(RB_I2C_SMBALERT);
        i2c_error = I2C_SMBALERT;
    }
}

static uint8_t MPU6050_Init(void) {
    uint8_t buf[2];
    int ret;

    // 1. 唤醒：写 PWR_MGMT_1 = 0x00  （从睡眠中醒来）
    buf[0] = REG_PWR_MGMT_1;
    buf[1] = 0x00;
    ret = I2C_Write(MPU6050_ADDR, buf, 2, /*wait=*/1, /*stop=*/1);
    if (ret) return -1;

    // 2. 采样率分频器：Sample Rate = Gyro Output Rate / (1 + SMPLRT_DIV)
    //    Gyro 输出频率 = 8kHz，当 DLPF 使能时是 1kHz，这里配置成 1kHz/ (1+7) = 125Hz
    //    SMPLRT_DIV = 7
    buf[0] = REG_SMPLRT_DIV;
    buf[1] = 7;  // 125Hz
    ret = I2C_Write(MPU6050_ADDR, buf, 2, 1, 1);
    if (ret) return -1;

    // 3. 低通滤波：CONFIG = 0x03 => DLPF使能，ACC带宽44Hz，GYRO带宽42Hz
    buf[0] = REG_CONFIG;
    buf[1] = 0x03;
    ret = I2C_Write(MPU6050_ADDR, buf, 2, 1, 1);
    if (ret) return -1;

    // 4. 陀螺仪量程：GYRO_CONFIG = 0x10 => ±1000°/s
    //    原始值范围 ±32768 对应 ±1000°/s => 1 LSB = 1000/32768 ≈ 0.0305 °/s
    buf[0] = REG_GYRO_CONFIG;
    buf[1] = 0x10;
    ret = I2C_Write(MPU6050_ADDR, buf, 2, 1, 1);
    if (ret) return -1;

    // 5. 加速度计量程：ACCEL_CONFIG = 0x00 => ±2g
    //    原始值范围 ±32768 对应 ±2g => 1 LSB = 2/32768 = 0.000061035 g
    buf[0] = REG_ACCEL_CONFIG;
    buf[1] = 0x00;
    ret = I2C_Write(MPU6050_ADDR, buf, 2, 1, 1);
    if (ret) return -1;

    return 0;
}

#define EVENT_SAMPLE_MPU6050 0x0001
#define EVENT_SEND_MPU6050 0x0002

/*******************************************************************************
 * @brief   传感器层事件处理函数
 * 
 * @param   task_id - TMOS分配的任务ID
 * @param   events  - 待处理事件(位图格式)
 */
tmosEvents Sensor_ProcessEvent(tmosTaskID task_id, tmosEvents events)
{
    uint8_t *msgPtr;
    static int len = 0;
    static uint8_t buf[14];
    
    if(events & SYS_EVENT_MSG)
    {
        msgPtr = tmos_msg_receive(task_id);
        if(msgPtr)
        {
            tmos_msg_deallocate(msgPtr); // 释放消息内存
        }
        return events ^ SYS_EVENT_MSG;
    }

    if(events & EVENT_SAMPLE_MPU6050){
        buf[0] = 0x3B;
        I2C_Write(MPU6050_ADDR, buf, 1, /*wait=*/1, /*stop=*/1);
        len = I2C_Read(MPU6050_ADDR, buf, 14, /*stop=*/1);
        
        tmos_start_task(sensorTaskID, EVENT_SEND_MPU6050, MS1_TO_SYSTEM_TIME(5));

        return events ^ EVENT_SAMPLE_MPU6050;
    }

    if(events & EVENT_SEND_MPU6050){
        if (len == 14){
         vuartNotifyData(buf,14);   
        }

        tmos_start_task(sensorTaskID, EVENT_SAMPLE_MPU6050, MS1_TO_SYSTEM_TIME(195));

        return events ^ EVENT_SEND_MPU6050;
    }
}

void SensorTask_Init(void)
{
    sensorTaskID = TMOS_ProcessEventRegister(Sensor_ProcessEvent);
    I2C_App_Init(0);

    if (MPU6050_Init() != 0) {
        while(1);
    }

    tmos_start_task(sensorTaskID, EVENT_SAMPLE_MPU6050, MS1_TO_SYSTEM_TIME(195));
}