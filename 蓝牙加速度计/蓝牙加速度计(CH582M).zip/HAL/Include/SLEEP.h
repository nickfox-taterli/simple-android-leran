#ifndef __SLEEP_H
#define __SLEEP_H

#ifdef __cplusplus
extern "C" {
#endif

/*********************************************************************
 * 睡眠管理接口
 *********************************************************************/

/**
 * @brief  初始化睡眠相关设置（如RTC唤醒方式、触发模式等）
 */
extern void HAL_SleepInit(void);

/**
 * @brief  进入低功耗睡眠模式，设置唤醒时间点
 *
 * @param  time  唤醒时间（RTC绝对时间戳）
 * @return 返回状态码（视具体实现而定）
 */
extern uint32_t CH58X_LowPower(uint32_t time);

#ifdef __cplusplus
}
#endif
#endif
