#ifndef __HAL_H
#define __HAL_H

#ifdef __cplusplus
extern "C" {
#endif

#include "CONFIG.h"
#include "RTC.h"
#include "SLEEP.h"

/* HAL 任务事件定义 */
#define HAL_REG_INIT_EVENT    0x0001

extern tmosTaskID halTaskID;

/**
 * @brief 硬件初始化函数，系统上电或复位时调用
 */
extern void HAL_Init(void);

/**
 * @brief 硬件层事件处理函数
 *
 * @param task_id TMOS 分配的任务 ID
 * @param events  要处理的事件，按位标识，可同时包含多个事件
 *
 * @return 未处理的事件（如果有）
 */
extern tmosEvents HAL_ProcessEvent(tmosTaskID task_id, tmosEvents events);

/**
 * @brief 初始化 BLE 库，准备协议栈相关资源
 */
extern void CH58X_BLEInit(void);

/**
 * @brief 读取内部温度传感器的 ADC 采样值
 *
 * 注意：如果启用了 ADC 中断采样，该函数内应屏蔽 ADC 中断避免冲突
 *
 * @return 温感采样的 ADC 值（未转换为温度）
 */
extern uint16_t HAL_GetInterTempValue(void);

/**
 * @brief 对内部 32kHz LSI 时钟进行校准，提升 RTC 等模块精度
 */
extern void Lib_Calibration_LSI(void);

#ifdef __cplusplus
}
#endif

#endif /* __HAL_H */
