#ifndef __RTC_H
#define __RTC_H

#ifdef __cplusplus
extern "C" {
#endif

// RTC 计时器的最大值（大约为 2.8 亿个时钟周期）
#define RTC_TIMER_MAX_VALUE    0xa8c00000

// 根据配置的 32KHz 时钟源，设置 RTC 频率
#ifdef CLK_OSC32K
#if (CLK_OSC32K == 1)
#define FREQ_RTC    32000      // 内部 RC 振荡器，32kHz
#else
#define FREQ_RTC    32768      // 外部晶振，32768Hz
#endif
#endif /* CLK_OSC32K */

// 时钟周期与时间单位之间的转换关系
#define CLK_PER_US      (1.0 / ((1.0 / FREQ_RTC) * 1000000)) // 每微秒多少个时钟
#define CLK_PER_MS      (CLK_PER_US * 1000)                  // 每毫秒多少个时钟
#define US_PER_CLK      (1.0 / CLK_PER_US)                   // 一个时钟等于多少微秒
#define MS_PER_CLK      (US_PER_CLK / 1000.0)                // 一个时钟等于多少毫秒

// RTC 时钟值与时间单位之间的转换宏（带四舍五入）
#define RTC_TO_US(clk)  ((uint32_t)((clk) * US_PER_CLK + 0.5))  // RTC -> 微秒
#define RTC_TO_MS(clk)  ((uint32_t)((clk) * MS_PER_CLK + 0.5))  // RTC -> 毫秒
#define US_TO_RTC(us)   ((uint32_t)((us) * CLK_PER_US + 0.5))   // 微秒 -> RTC
#define MS_TO_RTC(ms)   ((uint32_t)((ms) * CLK_PER_MS + 0.5))   // 毫秒 -> RTC

// RTC 触发标志，通常在中断中置位
extern volatile uint32_t RTCTigFlag;

/**
 * @brief  Initialize RTC time service (时钟模块初始化)
 */
void HAL_TimeInit(void);

/**
 * @brief  设置 RTC 中断触发时间
 * @param  time  RTC 时钟单位的触发时间
 */
void RTC_SetTignTime(uint32_t time);

#ifdef __cplusplus
}
#endif

#endif
