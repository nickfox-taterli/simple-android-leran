#include "HAL.h"

tmosTaskID halTaskID;

/*******************************************************************************
 * @brief   内部32kHz RC振荡器校准
 */
void Lib_Calibration_LSI(void)
{
    Calibration_LSI(Level_64);
}

#if(defined(BLE_SNV)) && (BLE_SNV == TRUE)
/*******************************************************************************
 * @brief   BLE库使用的Flash读取回调函数
 * 
 * @param   addr - 读取起始地址
 * @param   num  - 读取单位数(单位:4字节)
 * @param   pBuf - 数据存储缓冲区
 */
uint32_t Lib_Read_Flash(uint32_t addr, uint32_t num, uint32_t *pBuf)
{
    EEPROM_READ(addr, pBuf, num * 4);
    return 0;
}

/*******************************************************************************
 * @brief   BLE库使用的Flash写入回调函数
 * 
 * @param   addr - 写入起始地址
 * @param   num  - 写入单位数(单位:4字节)
 * @param   pBuf - 待写入数据缓冲区
 */
uint32_t Lib_Write_Flash(uint32_t addr, uint32_t num, uint32_t *pBuf)
{
    EEPROM_ERASE(addr, num * 4);
    EEPROM_WRITE(addr, pBuf, num * 4);
    return 0;
}
#endif

/*******************************************************************************
 * @brief   BLE库初始化
 */
void CH58X_BLEInit(void)
{
    uint8_t     i;
    bleConfig_t cfg;
    
    if(tmos_memcmp(VER_LIB, VER_FILE, strlen(VER_FILE)) == FALSE)
    {
        while(1);
    }
    
    SysTick_Config(SysTick_LOAD_RELOAD_Msk); // 配置SysTick定时器
    PFIC_DisableIRQ(SysTick_IRQn);
    
    tmos_memset(&cfg, 0, sizeof(bleConfig_t));
    cfg.MEMAddr = (uint32_t)MEM_BUF;
    cfg.MEMLen = (uint32_t)BLE_MEMHEAP_SIZE;
    cfg.BufMaxLen = (uint32_t)BLE_BUFF_MAX_LEN;
    cfg.BufNumber = (uint32_t)BLE_BUFF_NUM;
    cfg.TxNumEvent = (uint32_t)BLE_TX_NUM_EVENT;
    cfg.TxPower = (uint32_t)BLE_TX_POWER;
    
#if(defined(BLE_SNV)) && (BLE_SNV == TRUE)
    if((BLE_SNV_ADDR + BLE_SNV_BLOCK * BLE_SNV_NUM) > (0x78000 - FLASH_ROM_MAX_SIZE))
    {
        while(1);
    }
    cfg.SNVAddr = (uint32_t)BLE_SNV_ADDR;
    cfg.SNVBlock = (uint32_t)BLE_SNV_BLOCK;
    cfg.SNVNum = (uint32_t)BLE_SNV_NUM;
    cfg.readFlashCB = Lib_Read_Flash;
    cfg.writeFlashCB = Lib_Write_Flash;
#endif

#if(CLK_OSC32K)
    cfg.SelRTCClock = (uint32_t)CLK_OSC32K;
#endif

    cfg.ConnectNumber = (PERIPHERAL_MAX_CONNECTION & 3) | (CENTRAL_MAX_CONNECTION << 2);
    cfg.srandCB = SYS_GetSysTickCnt;
    
#if(defined TEM_SAMPLE) && (TEM_SAMPLE == TRUE)
    cfg.tsCB = HAL_GetInterTempValue;  // 温度采样回调(用于RF校准)
  #if(CLK_OSC32K)
    cfg.rcCB = Lib_Calibration_LSI;    // 内部32k RC校准回调
  #endif
#endif

#if(defined(HAL_SLEEP)) && (HAL_SLEEP == TRUE)
    cfg.WakeUpTime = WAKE_UP_RTC_MAX_TIME;
    cfg.sleepCB = CH58X_LowPower;      // 低功耗睡眠回调
#endif

#if(defined(BLE_MAC)) && (BLE_MAC == TRUE)
    for(i = 0; i < 6; i++)
    {
        cfg.MacAddr[i] = MacAddr[5 - i];
    }
#else
    {
        uint8_t MacAddr[6];
        GetMACAddress(MacAddr);
        for(i = 0; i < 6; i++)
        {
            cfg.MacAddr[i] = MacAddr[i]; // 使用芯片默认MAC地址
        }
    }
#endif

    if(!cfg.MEMAddr || cfg.MEMLen < 4 * 1024)
    {
        while(1);
    }
    
    i = BLE_LibInit(&cfg);
    if(i)
    {
        while(1);
    }
}

/*******************************************************************************
 * @brief   硬件层事件处理函数
 * 
 * @param   task_id - TMOS分配的任务ID
 * @param   events  - 待处理事件(位图格式)
 */
tmosEvents HAL_ProcessEvent(tmosTaskID task_id, tmosEvents events)
{
    uint8_t *msgPtr;
    
    if(events & SYS_EVENT_MSG)
    {
        msgPtr = tmos_msg_receive(task_id);
        if(msgPtr)
        {
            tmos_msg_deallocate(msgPtr); // 释放消息内存
        }
        return events ^ SYS_EVENT_MSG;
    }
    
    if(events & HAL_REG_INIT_EVENT)
    {
        uint8_t x32Kpw;
#if(defined BLE_CALIBRATION_ENABLE) && (BLE_CALIBRATION_ENABLE == TRUE)
        BLE_RegInit(); // RF校准
        
#if(CLK_OSC32K)
        Lib_Calibration_LSI(); // 内部RC校准
#else
        x32Kpw = (R8_XT32K_TUNE & 0xfc) | 0x01;
        sys_safe_access_enable();
        R8_XT32K_TUNE = x32Kpw; // 调整LSE驱动电流
        sys_safe_access_disable();
#endif
        
        tmos_start_task(halTaskID, HAL_REG_INIT_EVENT, MS1_TO_SYSTEM_TIME(BLE_CALIBRATION_PERIOD));
        return events ^ HAL_REG_INIT_EVENT;
#endif
    }
    
    return 0;
}

/*******************************************************************************
 * @brief   硬件层初始化
 */
void HAL_Init()
{
    halTaskID = TMOS_ProcessEventRegister(HAL_ProcessEvent);
    HAL_TimeInit();
    
#if(defined HAL_SLEEP) && (HAL_SLEEP == TRUE)
    HAL_SleepInit(); // 低功耗初始化
#endif
    
#if(defined HAL_LED) && (HAL_LED == TRUE)
    HAL_LedInit();   // LED初始化
#endif
    
#if(defined HAL_KEY) && (HAL_KEY == TRUE)
    HAL_KeyInit();   // 按键初始化
#endif
    
#if(defined BLE_CALIBRATION_ENABLE) && (BLE_CALIBRATION_ENABLE == TRUE)
    tmos_start_task(halTaskID, HAL_REG_INIT_EVENT, 800); // 启动校准任务
#endif
}

/*******************************************************************************
 * @brief   获取内部温度传感器采样值
 * 
 * @return  温度ADC采样值
 */
uint16_t HAL_GetInterTempValue(void)
{
    uint8_t  sensor, channel, config, tkey_cfg;
    uint16_t adc_data;
    
    // 保存当前配置
    tkey_cfg = R8_TKEY_CFG;
    sensor = R8_TEM_SENSOR;
    channel = R8_ADC_CHANNEL;
    config = R8_ADC_CFG;
    
    ADC_InterTSSampInit(); // 初始化温度采样
    
    R8_ADC_CONVERT |= RB_ADC_START;
    while(R8_ADC_CONVERT & RB_ADC_START);
    adc_data = R16_ADC_DATA;
    
    // 恢复原始配置
    R8_TEM_SENSOR = sensor;
    R8_ADC_CHANNEL = channel;
    R8_ADC_CFG = config;
    R8_TKEY_CFG = tkey_cfg;
    
    return (adc_data);
}