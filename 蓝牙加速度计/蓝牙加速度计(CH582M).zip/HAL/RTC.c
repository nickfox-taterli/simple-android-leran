#include "HAL.h"

/*********************************************************************
 * 常量定义：RTC 初始时间（时分秒）
 */
#define RTC_INIT_TIME_HOUR      0
#define RTC_INIT_TIME_MINUTE    0
#define RTC_INIT_TIME_SECEND    0

/***************************************************
 * 全局变量：RTC 触发标志（由中断置位）
 */
volatile uint32_t RTCTigFlag;

/*******************************************************************************
 * @fn      RTC_SetTignTime
 *
 * @brief   设置 RTC 触发时间（秒）
 *
 * @param   time - 触发时间（单位：秒）
 *
 * @return  None
 */
void RTC_SetTignTime(uint32_t time)
{
    sys_safe_access_enable();     // 允许写入安全寄存器
    R32_RTC_TRIG = time;          // 设置 RTC 触发时间
    sys_safe_access_disable();    // 禁止写入
    RTCTigFlag = 0;               // 清除触发标志
}

/*******************************************************************************
 * @fn      RTC_IRQHandler
 *
 * @brief   RTC 中断服务函数，清除中断标志并设置触发标志
 *
 * @param   None
 *
 * @return  None
 */
__INTERRUPT
__HIGH_CODE
void RTC_IRQHandler(void)
{
    // 清除 RTC 定时器和触发中断标志
    R8_RTC_FLAG_CTRL = (RB_RTC_TMR_CLR | RB_RTC_TRIG_CLR);
    RTCTigFlag = 1;  // 设置触发标志
}

/*******************************************************************************
 * @fn      HAL_TimeInit
 *
 * @brief   初始化系统时钟源并配置 RTC 时间
 *
 * @param   None
 *
 * @return  None
 */
void HAL_TimeInit(void)
{
#if(CLK_OSC32K)  // 使用内部 32K 时钟
    sys_safe_access_enable();
    R8_CK32K_CONFIG &= ~(RB_CLK_OSC32K_XT | RB_CLK_XT32K_PON);  // 禁用外部 32K 晶振
    sys_safe_access_disable();

    sys_safe_access_enable();
    R8_CK32K_CONFIG |= RB_CLK_INT32K_PON;  // 启用内部 32K 时钟
    sys_safe_access_disable();

    LSECFG_Current(LSE_RCur_100);      // 配置 RTC 工作电流
    Lib_Calibration_LSI();             // 校准内部低速时钟

#else  // 使用外部 32K 晶振
    sys_safe_access_enable();
    R8_CK32K_CONFIG |= RB_CLK_OSC32K_XT | RB_CLK_INT32K_PON | RB_CLK_XT32K_PON;
    sys_safe_access_disable();
#endif

    RTC_InitTime(2020, 1, 1, 0, 0, 0);  // 设置 RTC 当前时间（可修改成宏）
    TMOS_TimerInit(0);                 // 初始化系统定时器 0
}
